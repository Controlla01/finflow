﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.welc_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.creative_label = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.home_page_panel = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.loan_app_panel = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Guna2PictureBox6 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.lstPaymentSchedule = New System.Windows.Forms.ListBox()
        Me.Guna2GroupBox8 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TotalInterestt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TotalPrincipalReturnnn = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TotalInterest = New Guna.UI2.WinForms.Guna2TextBox()
        Me.TotalPrincipalReturnn = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel17 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GroupBox11 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Clear = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2GroupBox7 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.txtLoanAmount = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtLoanTerm = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnCalculateLoan = New Guna.UI2.WinForms.Guna2Button()
        Me.Boyleslaw_panel = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Guna2HtmlLabel8 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2PictureBox5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2GroupBox5 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.v2_txt = New System.Windows.Forms.TextBox()
        Me.v1_txt = New System.Windows.Forms.TextBox()
        Me.p2_txt = New System.Windows.Forms.TextBox()
        Me.p1_txt = New System.Windows.Forms.TextBox()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Guna2GroupBox6 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.calc_boyles_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Clear_txt = New Guna.UI2.WinForms.Guna2Button()
        Me.result_txtt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Guna2GroupBox10 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.v2_radio = New System.Windows.Forms.RadioButton()
        Me.p2_radio = New System.Windows.Forms.RadioButton()
        Me.p1_radio = New System.Windows.Forms.RadioButton()
        Me.v1_radio = New System.Windows.Forms.RadioButton()
        Me.AgeCalc_Panel2 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Guna2HtmlLabel7 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel6 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.days_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.months_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.years_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtBirthMonth = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.txtBirthDay = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.txtBirthYear = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Guna2PictureBox8 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2GroupBox3 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Guna2GroupBox4 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.btnCalculateAge = New Guna.UI2.WinForms.Guna2Button()
        Me.ClearButton = New Guna.UI2.WinForms.Guna2Button()
        Me.Gp_Calcu_Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2GroupBox17 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.first_semester_calc_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.second_semester_calc_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.first_semester_Panel = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2GroupBox13 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.TotalGPFirst_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.GPAFirst_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.GradeClassFirst_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtCourseUnitsFirst = New Guna.UI2.WinForms.Guna2TextBox()
        Me.ClearFirst_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.calcFirst_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.AGD106_txt = New System.Windows.Forms.TextBox()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NS105_txt = New System.Windows.Forms.TextBox()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.WAD104_txt = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MAD102_txt = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.SDA103_txt = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SDT101_txt = New System.Windows.Forms.TextBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Guna2TextBox10 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox11 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox12 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2TextBox13 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.second_semester_Panel = New System.Windows.Forms.Panel()
        Me.Guna2GroupBox16 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.GradeClassSecond_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.TotalGPSecond_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.calcSecond_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.ClearSecond_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.TotalGPASecond_txt = New Guna.UI2.WinForms.Guna2TextBox()
        Me.txtTotalCourseUnits2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.DevOp207_txt = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.DBMS201_txt = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.AI204_txt = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.AA206_txt = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.UIUX202_txt = New System.Windows.Forms.TextBox()
        Me.SQT205_txt = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Guna2Panel2 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2PictureBox4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2GroupBox2 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.TextBox3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.TextBox2 = New Guna.UI2.WinForms.Guna2TextBox()
        Me.btnClear = New Guna.UI2.WinForms.Guna2Button()
        Me.cmbUnit = New Guna.UI2.WinForms.Guna2ComboBox()
        Me.btnUnitConverter = New Guna.UI2.WinForms.Guna2Button()
        Me.input_con = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2GroupBox12 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.txtDisplay = New System.Windows.Forms.Label()
        Me.btnBackspace = New System.Windows.Forms.Button()
        Me.btnDel = New System.Windows.Forms.Button()
        Me.btnNo7 = New System.Windows.Forms.Button()
        Me.btnClr = New System.Windows.Forms.Button()
        Me.btnNegate = New System.Windows.Forms.Button()
        Me.btnNo4 = New System.Windows.Forms.Button()
        Me.btnNo8 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.btnNo9 = New System.Windows.Forms.Button()
        Me.btnNoplus = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.btnDot = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.btnEquals = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.txtShow = New System.Windows.Forms.TextBox()
        Me.Guna2PictureBox3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.simple_calc_panel = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.btnPercent = New System.Windows.Forms.Button()
        Me.btnOct = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.btnHex = New System.Windows.Forms.Button()
        Me.btnMod = New System.Windows.Forms.Button()
        Me.btnTan = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.btnBin = New System.Windows.Forms.Button()
        Me.btnCos = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.btnExp = New System.Windows.Forms.Button()
        Me.btnTanh = New System.Windows.Forms.Button()
        Me.btnSin = New System.Windows.Forms.Button()
        Me.btnCosh = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.BtnSqrt = New System.Windows.Forms.Button()
        Me.btnSignh = New System.Windows.Forms.Button()
        Me.btnLog = New System.Windows.Forms.Button()
        Me.btnPi = New System.Windows.Forms.Button()
        Me.Guna2GroupBox1 = New Guna.UI2.WinForms.Guna2GroupBox()
        Me.close_button = New Guna.UI2.WinForms.Guna2Button()
        Me.mini_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2Panel1 = New Guna.UI2.WinForms.Guna2Panel()
        Me.Guna2HtmlLabel11 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2CustomGradientPanel1 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Guna2CustomGradientPanel2 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.home_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.GpCalcu_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.simple_calc_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Unit_converterBtn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2Button4 = New Guna.UI2.WinForms.Guna2Button()
        Me.AgeCalc_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.LoanApp_btn = New Guna.UI2.WinForms.Guna2Button()
        Me.BOYLES_LAW_Btn = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2CirclePictureBox1 = New Guna.UI2.WinForms.Guna2CirclePictureBox()
        Me.Guna2HtmlLabel10 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel9 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.home_page_panel.SuspendLayout()
        Me.loan_app_panel.SuspendLayout()
        CType(Me.Guna2PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GroupBox8.SuspendLayout()
        Me.Guna2GroupBox11.SuspendLayout()
        Me.Guna2GroupBox7.SuspendLayout()
        Me.Boyleslaw_panel.SuspendLayout()
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GroupBox5.SuspendLayout()
        Me.Guna2GroupBox6.SuspendLayout()
        Me.Guna2GroupBox10.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.AgeCalc_Panel2.SuspendLayout()
        CType(Me.Guna2PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GroupBox4.SuspendLayout()
        Me.Gp_Calcu_Panel2.SuspendLayout()
        Me.Guna2GroupBox17.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.first_semester_Panel.SuspendLayout()
        Me.Guna2GroupBox13.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        Me.second_semester_Panel.SuspendLayout()
        Me.Guna2GroupBox16.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        Me.Guna2Panel2.SuspendLayout()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2GroupBox2.SuspendLayout()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.simple_calc_panel.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Guna2Panel1.SuspendLayout()
        Me.Guna2CustomGradientPanel1.SuspendLayout()
        Me.Guna2CustomGradientPanel2.SuspendLayout()
        CType(Me.Guna2CirclePictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'welc_label
        '
        Me.welc_label.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.welc_label.AutoSize = False
        Me.welc_label.BackColor = System.Drawing.Color.Transparent
        Me.welc_label.Font = New System.Drawing.Font("Lucida Sans Unicode", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.welc_label.ForeColor = System.Drawing.Color.White
        Me.welc_label.Location = New System.Drawing.Point(-8, 8)
        Me.welc_label.Margin = New System.Windows.Forms.Padding(2)
        Me.welc_label.Name = "welc_label"
        Me.welc_label.Size = New System.Drawing.Size(1510, 36)
        Me.welc_label.TabIndex = 4
        Me.welc_label.Text = "WELCOME TO AFOOTECH MULTI-FUNTION CALCULATOR"
        Me.welc_label.TextAlignment = System.Drawing.ContentAlignment.TopCenter
        '
        'creative_label
        '
        Me.creative_label.AutoSize = False
        Me.creative_label.BackColor = System.Drawing.Color.Transparent
        Me.creative_label.Font = New System.Drawing.Font("Segoe Print", 10.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.creative_label.ForeColor = System.Drawing.Color.OrangeRed
        Me.creative_label.Location = New System.Drawing.Point(827, 35)
        Me.creative_label.Margin = New System.Windows.Forms.Padding(2)
        Me.creative_label.Name = "creative_label"
        Me.creative_label.Size = New System.Drawing.Size(312, 23)
        Me.creative_label.TabIndex = 7
        Me.creative_label.Text = "CREATIVE & INNOVATIVE"
        Me.creative_label.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2PictureBox2.Image = CType(resources.GetObject("Guna2PictureBox2.Image"), System.Drawing.Image)
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(3, 49)
        Me.Guna2PictureBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.ShadowDecoration.Parent = Me.Guna2PictureBox2
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(1954, 797)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox2.TabIndex = 2
        Me.Guna2PictureBox2.TabStop = False
        '
        'home_page_panel
        '
        Me.home_page_panel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.home_page_panel.BorderRadius = 4
        Me.home_page_panel.Controls.Add(Me.Guna2PictureBox2)
        Me.home_page_panel.Location = New System.Drawing.Point(-19, 263)
        Me.home_page_panel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.home_page_panel.Name = "home_page_panel"
        Me.home_page_panel.ShadowDecoration.Parent = Me.home_page_panel
        Me.home_page_panel.Size = New System.Drawing.Size(1962, 850)
        Me.home_page_panel.TabIndex = 5
        '
        'loan_app_panel
        '
        Me.loan_app_panel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.loan_app_panel.BackColor = System.Drawing.Color.White
        Me.loan_app_panel.BorderRadius = 4
        Me.loan_app_panel.Controls.Add(Me.Label107)
        Me.loan_app_panel.Controls.Add(Me.Guna2PictureBox6)
        Me.loan_app_panel.Controls.Add(Me.lstPaymentSchedule)
        Me.loan_app_panel.Controls.Add(Me.Guna2GroupBox8)
        Me.loan_app_panel.Controls.Add(Me.Guna2GroupBox11)
        Me.loan_app_panel.Location = New System.Drawing.Point(-16, 289)
        Me.loan_app_panel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.loan_app_panel.Name = "loan_app_panel"
        Me.loan_app_panel.ShadowDecoration.Parent = Me.loan_app_panel
        Me.loan_app_panel.Size = New System.Drawing.Size(1922, 818)
        Me.loan_app_panel.TabIndex = 7
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Lucida Sans Unicode", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.Location = New System.Drawing.Point(1244, 54)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(163, 37)
        Me.Label107.TabIndex = 74
        Me.Label107.Text = "LOAN APP"
        '
        'Guna2PictureBox6
        '
        Me.Guna2PictureBox6.Image = CType(resources.GetObject("Guna2PictureBox6.Image"), System.Drawing.Image)
        Me.Guna2PictureBox6.Location = New System.Drawing.Point(0, -24)
        Me.Guna2PictureBox6.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2PictureBox6.Name = "Guna2PictureBox6"
        Me.Guna2PictureBox6.ShadowDecoration.Parent = Me.Guna2PictureBox6
        Me.Guna2PictureBox6.Size = New System.Drawing.Size(962, 817)
        Me.Guna2PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox6.TabIndex = 68
        Me.Guna2PictureBox6.TabStop = False
        '
        'lstPaymentSchedule
        '
        Me.lstPaymentSchedule.FormattingEnabled = True
        Me.lstPaymentSchedule.ItemHeight = 16
        Me.lstPaymentSchedule.Location = New System.Drawing.Point(1069, 417)
        Me.lstPaymentSchedule.Margin = New System.Windows.Forms.Padding(4)
        Me.lstPaymentSchedule.Name = "lstPaymentSchedule"
        Me.lstPaymentSchedule.ScrollAlwaysVisible = True
        Me.lstPaymentSchedule.Size = New System.Drawing.Size(664, 180)
        Me.lstPaymentSchedule.TabIndex = 63
        '
        'Guna2GroupBox8
        '
        Me.Guna2GroupBox8.Controls.Add(Me.TotalInterestt)
        Me.Guna2GroupBox8.Controls.Add(Me.TotalPrincipalReturnnn)
        Me.Guna2GroupBox8.Controls.Add(Me.TotalInterest)
        Me.Guna2GroupBox8.Controls.Add(Me.TotalPrincipalReturnn)
        Me.Guna2GroupBox8.Controls.Add(Me.Guna2HtmlLabel17)
        Me.Guna2GroupBox8.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox8.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.Guna2GroupBox8.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox8.Location = New System.Drawing.Point(1053, 358)
        Me.Guna2GroupBox8.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox8.Name = "Guna2GroupBox8"
        Me.Guna2GroupBox8.ShadowDecoration.Parent = Me.Guna2GroupBox8
        Me.Guna2GroupBox8.Size = New System.Drawing.Size(699, 343)
        Me.Guna2GroupBox8.TabIndex = 72
        Me.Guna2GroupBox8.Text = "Loan Payment Schedule"
        '
        'TotalInterestt
        '
        Me.TotalInterestt.BorderRadius = 3
        Me.TotalInterestt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalInterestt.DefaultText = ""
        Me.TotalInterestt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalInterestt.DisabledState.FillColor = System.Drawing.Color.White
        Me.TotalInterestt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalInterestt.DisabledState.Parent = Me.TotalInterestt
        Me.TotalInterestt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalInterestt.Enabled = False
        Me.TotalInterestt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalInterestt.FocusedState.Parent = Me.TotalInterestt
        Me.TotalInterestt.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.TotalInterestt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalInterestt.HoverState.Parent = Me.TotalInterestt
        Me.TotalInterestt.Location = New System.Drawing.Point(397, 274)
        Me.TotalInterestt.Margin = New System.Windows.Forms.Padding(4, 9, 4, 9)
        Me.TotalInterestt.Name = "TotalInterestt"
        Me.TotalInterestt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalInterestt.PlaceholderText = ""
        Me.TotalInterestt.SelectedText = ""
        Me.TotalInterestt.ShadowDecoration.Parent = Me.TotalInterestt
        Me.TotalInterestt.Size = New System.Drawing.Size(283, 44)
        Me.TotalInterestt.TabIndex = 2
        '
        'TotalPrincipalReturnnn
        '
        Me.TotalPrincipalReturnnn.BorderColor = System.Drawing.Color.Silver
        Me.TotalPrincipalReturnnn.BorderRadius = 3
        Me.TotalPrincipalReturnnn.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalPrincipalReturnnn.DefaultText = ""
        Me.TotalPrincipalReturnnn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalPrincipalReturnnn.DisabledState.FillColor = System.Drawing.Color.White
        Me.TotalPrincipalReturnnn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalPrincipalReturnnn.DisabledState.Parent = Me.TotalPrincipalReturnnn
        Me.TotalPrincipalReturnnn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalPrincipalReturnnn.Enabled = False
        Me.TotalPrincipalReturnnn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalPrincipalReturnnn.FocusedState.Parent = Me.TotalPrincipalReturnnn
        Me.TotalPrincipalReturnnn.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.TotalPrincipalReturnnn.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalPrincipalReturnnn.HoverState.Parent = Me.TotalPrincipalReturnnn
        Me.TotalPrincipalReturnnn.Location = New System.Drawing.Point(19, 274)
        Me.TotalPrincipalReturnnn.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.TotalPrincipalReturnnn.Name = "TotalPrincipalReturnnn"
        Me.TotalPrincipalReturnnn.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalPrincipalReturnnn.PlaceholderForeColor = System.Drawing.Color.White
        Me.TotalPrincipalReturnnn.PlaceholderText = ""
        Me.TotalPrincipalReturnnn.SelectedText = ""
        Me.TotalPrincipalReturnnn.ShadowDecoration.Parent = Me.TotalPrincipalReturnnn
        Me.TotalPrincipalReturnnn.Size = New System.Drawing.Size(319, 44)
        Me.TotalPrincipalReturnnn.TabIndex = 2
        '
        'TotalInterest
        '
        Me.TotalInterest.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalInterest.DefaultText = ""
        Me.TotalInterest.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalInterest.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TotalInterest.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalInterest.DisabledState.Parent = Me.TotalInterest
        Me.TotalInterest.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalInterest.Enabled = False
        Me.TotalInterest.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalInterest.FocusedState.Parent = Me.TotalInterest
        Me.TotalInterest.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TotalInterest.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalInterest.HoverState.Parent = Me.TotalInterest
        Me.TotalInterest.Location = New System.Drawing.Point(19, 390)
        Me.TotalInterest.Margin = New System.Windows.Forms.Padding(6, 7, 6, 7)
        Me.TotalInterest.Name = "TotalInterest"
        Me.TotalInterest.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalInterest.PlaceholderText = ""
        Me.TotalInterest.SelectedText = ""
        Me.TotalInterest.ShadowDecoration.Parent = Me.TotalInterest
        Me.TotalInterest.Size = New System.Drawing.Size(271, 70)
        Me.TotalInterest.TabIndex = 1
        '
        'TotalPrincipalReturnn
        '
        Me.TotalPrincipalReturnn.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalPrincipalReturnn.DefaultText = ""
        Me.TotalPrincipalReturnn.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalPrincipalReturnn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TotalPrincipalReturnn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalPrincipalReturnn.DisabledState.Parent = Me.TotalPrincipalReturnn
        Me.TotalPrincipalReturnn.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalPrincipalReturnn.Enabled = False
        Me.TotalPrincipalReturnn.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalPrincipalReturnn.FocusedState.Parent = Me.TotalPrincipalReturnn
        Me.TotalPrincipalReturnn.ForeColor = System.Drawing.Color.WhiteSmoke
        Me.TotalPrincipalReturnn.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalPrincipalReturnn.HoverState.Parent = Me.TotalPrincipalReturnn
        Me.TotalPrincipalReturnn.Location = New System.Drawing.Point(597, 568)
        Me.TotalPrincipalReturnn.Margin = New System.Windows.Forms.Padding(4, 9, 4, 9)
        Me.TotalPrincipalReturnn.Name = "TotalPrincipalReturnn"
        Me.TotalPrincipalReturnn.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalPrincipalReturnn.PlaceholderText = ""
        Me.TotalPrincipalReturnn.SelectedText = ""
        Me.TotalPrincipalReturnn.ShadowDecoration.Parent = Me.TotalPrincipalReturnn
        Me.TotalPrincipalReturnn.Size = New System.Drawing.Size(262, 98)
        Me.TotalPrincipalReturnn.TabIndex = 1
        '
        'Guna2HtmlLabel17
        '
        Me.Guna2HtmlLabel17.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel17.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Guna2HtmlLabel17.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel17.Location = New System.Drawing.Point(43, 249)
        Me.Guna2HtmlLabel17.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel17.Name = "Guna2HtmlLabel17"
        Me.Guna2HtmlLabel17.Size = New System.Drawing.Size(106, 27)
        Me.Guna2HtmlLabel17.TabIndex = 0
        Me.Guna2HtmlLabel17.Text = "Total Interest"
        '
        'Guna2GroupBox11
        '
        Me.Guna2GroupBox11.Controls.Add(Me.Clear)
        Me.Guna2GroupBox11.Controls.Add(Me.Guna2GroupBox7)
        Me.Guna2GroupBox11.Controls.Add(Me.btnCalculateLoan)
        Me.Guna2GroupBox11.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox11.Font = New System.Drawing.Font("Lucida Sans Unicode", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox11.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox11.Location = New System.Drawing.Point(1026, 101)
        Me.Guna2GroupBox11.Name = "Guna2GroupBox11"
        Me.Guna2GroupBox11.ShadowDecoration.Parent = Me.Guna2GroupBox11
        Me.Guna2GroupBox11.Size = New System.Drawing.Size(760, 614)
        Me.Guna2GroupBox11.TabIndex = 73
        Me.Guna2GroupBox11.Text = "Input Loan Details"
        '
        'Clear
        '
        Me.Clear.BorderRadius = 4
        Me.Clear.CheckedState.Parent = Me.Clear
        Me.Clear.CustomImages.Parent = Me.Clear
        Me.Clear.FillColor = System.Drawing.Color.Red
        Me.Clear.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear.ForeColor = System.Drawing.Color.White
        Me.Clear.HoverState.Parent = Me.Clear
        Me.Clear.Location = New System.Drawing.Point(564, 184)
        Me.Clear.Name = "Clear"
        Me.Clear.ShadowDecoration.Parent = Me.Clear
        Me.Clear.Size = New System.Drawing.Size(143, 55)
        Me.Clear.TabIndex = 0
        Me.Clear.Text = "CLEAR"
        '
        'Guna2GroupBox7
        '
        Me.Guna2GroupBox7.Controls.Add(Me.Label109)
        Me.Guna2GroupBox7.Controls.Add(Me.Label108)
        Me.Guna2GroupBox7.Controls.Add(Me.txtLoanAmount)
        Me.Guna2GroupBox7.Controls.Add(Me.txtLoanTerm)
        Me.Guna2GroupBox7.CustomBorderColor = System.Drawing.Color.White
        Me.Guna2GroupBox7.FillColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Guna2GroupBox7.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2GroupBox7.Location = New System.Drawing.Point(27, 51)
        Me.Guna2GroupBox7.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox7.Name = "Guna2GroupBox7"
        Me.Guna2GroupBox7.ShadowDecoration.Parent = Me.Guna2GroupBox7
        Me.Guna2GroupBox7.Size = New System.Drawing.Size(697, 113)
        Me.Guna2GroupBox7.TabIndex = 70
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.ForeColor = System.Drawing.Color.Black
        Me.Label109.Location = New System.Drawing.Point(468, 19)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(213, 25)
        Me.Label109.TabIndex = 2
        Me.Label109.Text = "Enter the Loan Duration"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.ForeColor = System.Drawing.Color.Black
        Me.Label108.Location = New System.Drawing.Point(11, 17)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(206, 25)
        Me.Label108.TabIndex = 2
        Me.Label108.Text = "Enter the Loan Amount"
        '
        'txtLoanAmount
        '
        Me.txtLoanAmount.BorderRadius = 3
        Me.txtLoanAmount.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLoanAmount.DefaultText = ""
        Me.txtLoanAmount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtLoanAmount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtLoanAmount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtLoanAmount.DisabledState.Parent = Me.txtLoanAmount
        Me.txtLoanAmount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtLoanAmount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLoanAmount.FocusedState.Parent = Me.txtLoanAmount
        Me.txtLoanAmount.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtLoanAmount.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLoanAmount.HoverState.Parent = Me.txtLoanAmount
        Me.txtLoanAmount.Location = New System.Drawing.Point(16, 47)
        Me.txtLoanAmount.Margin = New System.Windows.Forms.Padding(5)
        Me.txtLoanAmount.Name = "txtLoanAmount"
        Me.txtLoanAmount.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtLoanAmount.PlaceholderText = ""
        Me.txtLoanAmount.SelectedText = ""
        Me.txtLoanAmount.ShadowDecoration.Parent = Me.txtLoanAmount
        Me.txtLoanAmount.Size = New System.Drawing.Size(241, 49)
        Me.txtLoanAmount.TabIndex = 1
        '
        'txtLoanTerm
        '
        Me.txtLoanTerm.BorderRadius = 3
        Me.txtLoanTerm.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtLoanTerm.DefaultText = ""
        Me.txtLoanTerm.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtLoanTerm.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtLoanTerm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtLoanTerm.DisabledState.Parent = Me.txtLoanTerm
        Me.txtLoanTerm.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtLoanTerm.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLoanTerm.FocusedState.Parent = Me.txtLoanTerm
        Me.txtLoanTerm.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.txtLoanTerm.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtLoanTerm.HoverState.Parent = Me.txtLoanTerm
        Me.txtLoanTerm.Location = New System.Drawing.Point(473, 52)
        Me.txtLoanTerm.Margin = New System.Windows.Forms.Padding(5)
        Me.txtLoanTerm.Name = "txtLoanTerm"
        Me.txtLoanTerm.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtLoanTerm.PlaceholderText = ""
        Me.txtLoanTerm.SelectedText = ""
        Me.txtLoanTerm.ShadowDecoration.Parent = Me.txtLoanTerm
        Me.txtLoanTerm.Size = New System.Drawing.Size(207, 47)
        Me.txtLoanTerm.TabIndex = 1
        '
        'btnCalculateLoan
        '
        Me.btnCalculateLoan.BorderRadius = 4
        Me.btnCalculateLoan.CheckedState.Parent = Me.btnCalculateLoan
        Me.btnCalculateLoan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCalculateLoan.CustomImages.Parent = Me.btnCalculateLoan
        Me.btnCalculateLoan.FillColor = System.Drawing.SystemColors.HotTrack
        Me.btnCalculateLoan.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateLoan.ForeColor = System.Drawing.Color.White
        Me.btnCalculateLoan.HoverState.Parent = Me.btnCalculateLoan
        Me.btnCalculateLoan.Location = New System.Drawing.Point(43, 184)
        Me.btnCalculateLoan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCalculateLoan.Name = "btnCalculateLoan"
        Me.btnCalculateLoan.ShadowDecoration.Parent = Me.btnCalculateLoan
        Me.btnCalculateLoan.Size = New System.Drawing.Size(259, 54)
        Me.btnCalculateLoan.TabIndex = 71
        Me.btnCalculateLoan.Text = "CALCULATE"
        '
        'Boyleslaw_panel
        '
        Me.Boyleslaw_panel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Boyleslaw_panel.BackColor = System.Drawing.Color.White
        Me.Boyleslaw_panel.BorderRadius = 4
        Me.Boyleslaw_panel.Controls.Add(Me.Guna2HtmlLabel8)
        Me.Boyleslaw_panel.Controls.Add(Me.Guna2PictureBox5)
        Me.Boyleslaw_panel.Controls.Add(Me.Guna2GroupBox5)
        Me.Boyleslaw_panel.Controls.Add(Me.Guna2GroupBox6)
        Me.Boyleslaw_panel.Controls.Add(Me.Guna2GroupBox10)
        Me.Boyleslaw_panel.FillColor = System.Drawing.SystemColors.ButtonFace
        Me.Boyleslaw_panel.Location = New System.Drawing.Point(0, 289)
        Me.Boyleslaw_panel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Boyleslaw_panel.Name = "Boyleslaw_panel"
        Me.Boyleslaw_panel.ShadowDecoration.Parent = Me.Boyleslaw_panel
        Me.Boyleslaw_panel.Size = New System.Drawing.Size(1915, 820)
        Me.Boyleslaw_panel.TabIndex = 8
        '
        'Guna2HtmlLabel8
        '
        Me.Guna2HtmlLabel8.AutoSize = False
        Me.Guna2HtmlLabel8.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel8.Font = New System.Drawing.Font("Lucida Sans Unicode", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel8.Location = New System.Drawing.Point(1129, 97)
        Me.Guna2HtmlLabel8.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel8.Name = "Guna2HtmlLabel8"
        Me.Guna2HtmlLabel8.Size = New System.Drawing.Size(671, 38)
        Me.Guna2HtmlLabel8.TabIndex = 74
        Me.Guna2HtmlLabel8.Text = "BOYLE'S LAW CALCULATOR"
        '
        'Guna2PictureBox5
        '
        Me.Guna2PictureBox5.Image = CType(resources.GetObject("Guna2PictureBox5.Image"), System.Drawing.Image)
        Me.Guna2PictureBox5.Location = New System.Drawing.Point(27, -3)
        Me.Guna2PictureBox5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox5.Name = "Guna2PictureBox5"
        Me.Guna2PictureBox5.ShadowDecoration.Parent = Me.Guna2PictureBox5
        Me.Guna2PictureBox5.Size = New System.Drawing.Size(813, 803)
        Me.Guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox5.TabIndex = 0
        Me.Guna2PictureBox5.TabStop = False
        '
        'Guna2GroupBox5
        '
        Me.Guna2GroupBox5.Controls.Add(Me.v2_txt)
        Me.Guna2GroupBox5.Controls.Add(Me.v1_txt)
        Me.Guna2GroupBox5.Controls.Add(Me.p2_txt)
        Me.Guna2GroupBox5.Controls.Add(Me.p1_txt)
        Me.Guna2GroupBox5.Controls.Add(Me.Label105)
        Me.Guna2GroupBox5.Controls.Add(Me.Label103)
        Me.Guna2GroupBox5.Controls.Add(Me.Label104)
        Me.Guna2GroupBox5.Controls.Add(Me.Label102)
        Me.Guna2GroupBox5.CustomBorderColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Guna2GroupBox5.CustomBorderThickness = New System.Windows.Forms.Padding(0)
        Me.Guna2GroupBox5.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2GroupBox5.Location = New System.Drawing.Point(1196, 222)
        Me.Guna2GroupBox5.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox5.Name = "Guna2GroupBox5"
        Me.Guna2GroupBox5.ShadowDecoration.Parent = Me.Guna2GroupBox5
        Me.Guna2GroupBox5.Size = New System.Drawing.Size(676, 225)
        Me.Guna2GroupBox5.TabIndex = 77
        '
        'v2_txt
        '
        Me.v2_txt.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.v2_txt.Location = New System.Drawing.Point(356, 157)
        Me.v2_txt.Multiline = True
        Me.v2_txt.Name = "v2_txt"
        Me.v2_txt.Size = New System.Drawing.Size(279, 49)
        Me.v2_txt.TabIndex = 79
        Me.v2_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'v1_txt
        '
        Me.v1_txt.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.v1_txt.Location = New System.Drawing.Point(31, 159)
        Me.v1_txt.Multiline = True
        Me.v1_txt.Name = "v1_txt"
        Me.v1_txt.Size = New System.Drawing.Size(279, 49)
        Me.v1_txt.TabIndex = 79
        Me.v1_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'p2_txt
        '
        Me.p2_txt.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.p2_txt.Location = New System.Drawing.Point(356, 52)
        Me.p2_txt.Multiline = True
        Me.p2_txt.Name = "p2_txt"
        Me.p2_txt.Size = New System.Drawing.Size(279, 49)
        Me.p2_txt.TabIndex = 79
        Me.p2_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'p1_txt
        '
        Me.p1_txt.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.p1_txt.Location = New System.Drawing.Point(31, 53)
        Me.p1_txt.Multiline = True
        Me.p1_txt.Name = "p1_txt"
        Me.p1_txt.Size = New System.Drawing.Size(279, 49)
        Me.p1_txt.TabIndex = 79
        Me.p1_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label105.ForeColor = System.Drawing.Color.Black
        Me.Label105.Location = New System.Drawing.Point(371, 117)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(210, 28)
        Me.Label105.TabIndex = 78
        Me.Label105.Text = "Input final volume (V2)"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label103.ForeColor = System.Drawing.Color.Black
        Me.Label103.Location = New System.Drawing.Point(367, 21)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(217, 28)
        Me.Label103.TabIndex = 78
        Me.Label103.Text = "Input final pressure (P2)"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label104.ForeColor = System.Drawing.Color.Black
        Me.Label104.Location = New System.Drawing.Point(43, 125)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(221, 28)
        Me.Label104.TabIndex = 77
        Me.Label104.Text = "Input initial volume (V1)"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label102.ForeColor = System.Drawing.Color.Black
        Me.Label102.Location = New System.Drawing.Point(43, 20)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(222, 28)
        Me.Label102.TabIndex = 77
        Me.Label102.Text = "Input initial Pressure(P1)"
        '
        'Guna2GroupBox6
        '
        Me.Guna2GroupBox6.BackColor = System.Drawing.SystemColors.Control
        Me.Guna2GroupBox6.Controls.Add(Me.calc_boyles_btn)
        Me.Guna2GroupBox6.Controls.Add(Me.Clear_txt)
        Me.Guna2GroupBox6.Controls.Add(Me.result_txtt)
        Me.Guna2GroupBox6.Controls.Add(Me.Label106)
        Me.Guna2GroupBox6.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox6.CustomBorderThickness = New System.Windows.Forms.Padding(0, 30, 0, 0)
        Me.Guna2GroupBox6.FillColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Guna2GroupBox6.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox6.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox6.Location = New System.Drawing.Point(1196, 466)
        Me.Guna2GroupBox6.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox6.Name = "Guna2GroupBox6"
        Me.Guna2GroupBox6.ShadowDecoration.Parent = Me.Guna2GroupBox6
        Me.Guna2GroupBox6.Size = New System.Drawing.Size(676, 218)
        Me.Guna2GroupBox6.TabIndex = 79
        Me.Guna2GroupBox6.Text = "Next is Calculate"
        '
        'calc_boyles_btn
        '
        Me.calc_boyles_btn.BorderRadius = 4
        Me.calc_boyles_btn.CheckedState.Parent = Me.calc_boyles_btn
        Me.calc_boyles_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.calc_boyles_btn.CustomImages.Parent = Me.calc_boyles_btn
        Me.calc_boyles_btn.FillColor = System.Drawing.SystemColors.HotTrack
        Me.calc_boyles_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calc_boyles_btn.ForeColor = System.Drawing.Color.White
        Me.calc_boyles_btn.HoverState.Parent = Me.calc_boyles_btn
        Me.calc_boyles_btn.Location = New System.Drawing.Point(31, 53)
        Me.calc_boyles_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.calc_boyles_btn.Name = "calc_boyles_btn"
        Me.calc_boyles_btn.ShadowDecoration.Parent = Me.calc_boyles_btn
        Me.calc_boyles_btn.Size = New System.Drawing.Size(243, 47)
        Me.calc_boyles_btn.TabIndex = 78
        Me.calc_boyles_btn.Text = "CALCULATE"
        '
        'Clear_txt
        '
        Me.Clear_txt.BorderRadius = 4
        Me.Clear_txt.CheckedState.Parent = Me.Clear_txt
        Me.Clear_txt.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Clear_txt.CustomImages.Parent = Me.Clear_txt
        Me.Clear_txt.FillColor = System.Drawing.Color.Red
        Me.Clear_txt.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear_txt.ForeColor = System.Drawing.Color.White
        Me.Clear_txt.HoverState.Parent = Me.Clear_txt
        Me.Clear_txt.Location = New System.Drawing.Point(476, 53)
        Me.Clear_txt.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Clear_txt.Name = "Clear_txt"
        Me.Clear_txt.ShadowDecoration.Parent = Me.Clear_txt
        Me.Clear_txt.Size = New System.Drawing.Size(164, 47)
        Me.Clear_txt.TabIndex = 78
        Me.Clear_txt.Text = "CLEAR"
        '
        'result_txtt
        '
        Me.result_txtt.BorderRadius = 3
        Me.result_txtt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.result_txtt.DefaultText = ""
        Me.result_txtt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.result_txtt.DisabledState.FillColor = System.Drawing.Color.White
        Me.result_txtt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.result_txtt.DisabledState.Parent = Me.result_txtt
        Me.result_txtt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.result_txtt.Enabled = False
        Me.result_txtt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.result_txtt.FocusedState.Parent = Me.result_txtt
        Me.result_txtt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.result_txtt.HoverState.Parent = Me.result_txtt
        Me.result_txtt.Location = New System.Drawing.Point(31, 144)
        Me.result_txtt.Margin = New System.Windows.Forms.Padding(5, 6, 5, 6)
        Me.result_txtt.Name = "result_txtt"
        Me.result_txtt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.result_txtt.PlaceholderText = ""
        Me.result_txtt.SelectedText = ""
        Me.result_txtt.ShadowDecoration.Parent = Me.result_txtt
        Me.result_txtt.Size = New System.Drawing.Size(609, 63)
        Me.result_txtt.TabIndex = 76
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label106.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Label106.ForeColor = System.Drawing.Color.Black
        Me.Label106.Location = New System.Drawing.Point(28, 108)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(72, 28)
        Me.Label106.TabIndex = 77
        Me.Label106.Text = "Results"
        '
        'Guna2GroupBox10
        '
        Me.Guna2GroupBox10.Controls.Add(Me.GroupBox2)
        Me.Guna2GroupBox10.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox10.Font = New System.Drawing.Font("Lucida Sans Unicode", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox10.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox10.Location = New System.Drawing.Point(879, 155)
        Me.Guna2GroupBox10.Name = "Guna2GroupBox10"
        Me.Guna2GroupBox10.ShadowDecoration.Parent = Me.Guna2GroupBox10
        Me.Guna2GroupBox10.Size = New System.Drawing.Size(1011, 549)
        Me.Guna2GroupBox10.TabIndex = 80
        Me.Guna2GroupBox10.Text = "Input Values to Calculate"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.Window
        Me.GroupBox2.Controls.Add(Me.v2_radio)
        Me.GroupBox2.Controls.Add(Me.p2_radio)
        Me.GroupBox2.Controls.Add(Me.p1_radio)
        Me.GroupBox2.Controls.Add(Me.v1_radio)
        Me.GroupBox2.Location = New System.Drawing.Point(16, 52)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(288, 242)
        Me.GroupBox2.TabIndex = 72
        Me.GroupBox2.TabStop = False
        '
        'v2_radio
        '
        Me.v2_radio.BackColor = System.Drawing.SystemColors.Window
        Me.v2_radio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.v2_radio.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.v2_radio.Location = New System.Drawing.Point(31, 167)
        Me.v2_radio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.v2_radio.Name = "v2_radio"
        Me.v2_radio.Size = New System.Drawing.Size(217, 44)
        Me.v2_radio.TabIndex = 62
        Me.v2_radio.TabStop = True
        Me.v2_radio.Text = "Final Volume     (V2)"
        Me.v2_radio.UseVisualStyleBackColor = False
        '
        'p2_radio
        '
        Me.p2_radio.BackColor = System.Drawing.SystemColors.Window
        Me.p2_radio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.p2_radio.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p2_radio.Location = New System.Drawing.Point(31, 126)
        Me.p2_radio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.p2_radio.Name = "p2_radio"
        Me.p2_radio.Size = New System.Drawing.Size(217, 37)
        Me.p2_radio.TabIndex = 61
        Me.p2_radio.TabStop = True
        Me.p2_radio.Text = "Final Pressure  (P2)"
        Me.p2_radio.UseVisualStyleBackColor = False
        '
        'p1_radio
        '
        Me.p1_radio.BackColor = System.Drawing.SystemColors.Window
        Me.p1_radio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.p1_radio.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p1_radio.Location = New System.Drawing.Point(31, 33)
        Me.p1_radio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.p1_radio.Name = "p1_radio"
        Me.p1_radio.Size = New System.Drawing.Size(217, 32)
        Me.p1_radio.TabIndex = 59
        Me.p1_radio.TabStop = True
        Me.p1_radio.Text = "Initial Pressure (P1)"
        Me.p1_radio.UseVisualStyleBackColor = False
        '
        'v1_radio
        '
        Me.v1_radio.BackColor = System.Drawing.SystemColors.Window
        Me.v1_radio.Cursor = System.Windows.Forms.Cursors.Hand
        Me.v1_radio.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.v1_radio.Location = New System.Drawing.Point(31, 71)
        Me.v1_radio.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.v1_radio.Name = "v1_radio"
        Me.v1_radio.Size = New System.Drawing.Size(217, 48)
        Me.v1_radio.TabIndex = 60
        Me.v1_radio.TabStop = True
        Me.v1_radio.Text = "Initial Volume    (V1)"
        Me.v1_radio.UseVisualStyleBackColor = False
        '
        'AgeCalc_Panel2
        '
        Me.AgeCalc_Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AgeCalc_Panel2.BorderRadius = 4
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2HtmlLabel7)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2HtmlLabel6)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2HtmlLabel5)
        Me.AgeCalc_Panel2.Controls.Add(Me.days_txt)
        Me.AgeCalc_Panel2.Controls.Add(Me.months_txt)
        Me.AgeCalc_Panel2.Controls.Add(Me.years_txt)
        Me.AgeCalc_Panel2.Controls.Add(Me.txtBirthMonth)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2HtmlLabel3)
        Me.AgeCalc_Panel2.Controls.Add(Me.txtBirthDay)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2HtmlLabel4)
        Me.AgeCalc_Panel2.Controls.Add(Me.txtBirthYear)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2HtmlLabel2)
        Me.AgeCalc_Panel2.Controls.Add(Me.Label20)
        Me.AgeCalc_Panel2.Controls.Add(Me.DateTimePicker1)
        Me.AgeCalc_Panel2.Controls.Add(Me.Label22)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2PictureBox8)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2GroupBox3)
        Me.AgeCalc_Panel2.Controls.Add(Me.Guna2GroupBox4)
        Me.AgeCalc_Panel2.Location = New System.Drawing.Point(0, 289)
        Me.AgeCalc_Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.AgeCalc_Panel2.Name = "AgeCalc_Panel2"
        Me.AgeCalc_Panel2.ShadowDecoration.Parent = Me.AgeCalc_Panel2
        Me.AgeCalc_Panel2.Size = New System.Drawing.Size(1946, 803)
        Me.AgeCalc_Panel2.TabIndex = 9
        '
        'Guna2HtmlLabel7
        '
        Me.Guna2HtmlLabel7.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel7.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel7.Location = New System.Drawing.Point(1556, 663)
        Me.Guna2HtmlLabel7.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel7.Name = "Guna2HtmlLabel7"
        Me.Guna2HtmlLabel7.Size = New System.Drawing.Size(45, 22)
        Me.Guna2HtmlLabel7.TabIndex = 63
        Me.Guna2HtmlLabel7.Text = "DAYS"
        '
        'Guna2HtmlLabel6
        '
        Me.Guna2HtmlLabel6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel6.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel6.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel6.Location = New System.Drawing.Point(1367, 663)
        Me.Guna2HtmlLabel6.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel6.Name = "Guna2HtmlLabel6"
        Me.Guna2HtmlLabel6.Size = New System.Drawing.Size(72, 22)
        Me.Guna2HtmlLabel6.TabIndex = 62
        Me.Guna2HtmlLabel6.Text = "MONTHS"
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(1173, 663)
        Me.Guna2HtmlLabel5.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(52, 22)
        Me.Guna2HtmlLabel5.TabIndex = 61
        Me.Guna2HtmlLabel5.Text = "YEARS"
        '
        'days_txt
        '
        Me.days_txt.BorderRadius = 3
        Me.days_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.days_txt.DefaultText = ""
        Me.days_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.days_txt.DisabledState.FillColor = System.Drawing.Color.White
        Me.days_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.days_txt.DisabledState.Parent = Me.days_txt
        Me.days_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.days_txt.Enabled = False
        Me.days_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.days_txt.FocusedState.Parent = Me.days_txt
        Me.days_txt.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.days_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.days_txt.HoverState.Parent = Me.days_txt
        Me.days_txt.Location = New System.Drawing.Point(1556, 597)
        Me.days_txt.Margin = New System.Windows.Forms.Padding(5)
        Me.days_txt.Name = "days_txt"
        Me.days_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.days_txt.PlaceholderText = ""
        Me.days_txt.SelectedText = ""
        Me.days_txt.ShadowDecoration.Parent = Me.days_txt
        Me.days_txt.Size = New System.Drawing.Size(163, 63)
        Me.days_txt.TabIndex = 60
        '
        'months_txt
        '
        Me.months_txt.BorderRadius = 3
        Me.months_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.months_txt.DefaultText = ""
        Me.months_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.months_txt.DisabledState.FillColor = System.Drawing.Color.White
        Me.months_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.months_txt.DisabledState.Parent = Me.months_txt
        Me.months_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.months_txt.Enabled = False
        Me.months_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.months_txt.FocusedState.Parent = Me.months_txt
        Me.months_txt.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.months_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.months_txt.HoverState.Parent = Me.months_txt
        Me.months_txt.Location = New System.Drawing.Point(1367, 597)
        Me.months_txt.Margin = New System.Windows.Forms.Padding(5)
        Me.months_txt.Name = "months_txt"
        Me.months_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.months_txt.PlaceholderText = ""
        Me.months_txt.SelectedText = ""
        Me.months_txt.ShadowDecoration.Parent = Me.months_txt
        Me.months_txt.Size = New System.Drawing.Size(163, 63)
        Me.months_txt.TabIndex = 60
        '
        'years_txt
        '
        Me.years_txt.BorderRadius = 3
        Me.years_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.years_txt.DefaultText = ""
        Me.years_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.years_txt.DisabledState.FillColor = System.Drawing.Color.White
        Me.years_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.years_txt.DisabledState.Parent = Me.years_txt
        Me.years_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.years_txt.Enabled = False
        Me.years_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.years_txt.FocusedState.Parent = Me.years_txt
        Me.years_txt.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.years_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.years_txt.HoverState.Parent = Me.years_txt
        Me.years_txt.Location = New System.Drawing.Point(1173, 597)
        Me.years_txt.Margin = New System.Windows.Forms.Padding(5)
        Me.years_txt.Name = "years_txt"
        Me.years_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.years_txt.PlaceholderText = ""
        Me.years_txt.SelectedText = ""
        Me.years_txt.ShadowDecoration.Parent = Me.years_txt
        Me.years_txt.Size = New System.Drawing.Size(163, 63)
        Me.years_txt.TabIndex = 60
        '
        'txtBirthMonth
        '
        Me.txtBirthMonth.BorderRadius = 3
        Me.txtBirthMonth.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBirthMonth.DefaultText = ""
        Me.txtBirthMonth.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtBirthMonth.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtBirthMonth.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtBirthMonth.DisabledState.Parent = Me.txtBirthMonth
        Me.txtBirthMonth.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtBirthMonth.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtBirthMonth.FocusedState.Parent = Me.txtBirthMonth
        Me.txtBirthMonth.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtBirthMonth.ForeColor = System.Drawing.Color.Black
        Me.txtBirthMonth.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtBirthMonth.HoverState.Parent = Me.txtBirthMonth
        Me.txtBirthMonth.Location = New System.Drawing.Point(1173, 288)
        Me.txtBirthMonth.Margin = New System.Windows.Forms.Padding(5)
        Me.txtBirthMonth.Name = "txtBirthMonth"
        Me.txtBirthMonth.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtBirthMonth.PlaceholderText = ""
        Me.txtBirthMonth.SelectedText = ""
        Me.txtBirthMonth.ShadowDecoration.Parent = Me.txtBirthMonth
        Me.txtBirthMonth.Size = New System.Drawing.Size(545, 55)
        Me.txtBirthMonth.TabIndex = 58
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(1173, 262)
        Me.Guna2HtmlLabel3.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(184, 22)
        Me.Guna2HtmlLabel3.TabIndex = 57
        Me.Guna2HtmlLabel3.Text = "Input Your Birth month"
        '
        'txtBirthDay
        '
        Me.txtBirthDay.BorderRadius = 3
        Me.txtBirthDay.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBirthDay.DefaultText = ""
        Me.txtBirthDay.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtBirthDay.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtBirthDay.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtBirthDay.DisabledState.Parent = Me.txtBirthDay
        Me.txtBirthDay.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtBirthDay.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtBirthDay.FocusedState.Parent = Me.txtBirthDay
        Me.txtBirthDay.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtBirthDay.ForeColor = System.Drawing.Color.Black
        Me.txtBirthDay.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtBirthDay.HoverState.Parent = Me.txtBirthDay
        Me.txtBirthDay.Location = New System.Drawing.Point(1173, 383)
        Me.txtBirthDay.Margin = New System.Windows.Forms.Padding(5)
        Me.txtBirthDay.Name = "txtBirthDay"
        Me.txtBirthDay.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtBirthDay.PlaceholderText = ""
        Me.txtBirthDay.SelectedText = ""
        Me.txtBirthDay.ShadowDecoration.Parent = Me.txtBirthDay
        Me.txtBirthDay.Size = New System.Drawing.Size(545, 55)
        Me.txtBirthDay.TabIndex = 58
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(1173, 353)
        Me.Guna2HtmlLabel4.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(160, 22)
        Me.Guna2HtmlLabel4.TabIndex = 57
        Me.Guna2HtmlLabel4.Text = "Input Your Birth day"
        '
        'txtBirthYear
        '
        Me.txtBirthYear.BorderRadius = 3
        Me.txtBirthYear.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtBirthYear.DefaultText = ""
        Me.txtBirthYear.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtBirthYear.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtBirthYear.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtBirthYear.DisabledState.Parent = Me.txtBirthYear
        Me.txtBirthYear.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtBirthYear.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtBirthYear.FocusedState.Parent = Me.txtBirthYear
        Me.txtBirthYear.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.txtBirthYear.ForeColor = System.Drawing.Color.Black
        Me.txtBirthYear.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtBirthYear.HoverState.Parent = Me.txtBirthYear
        Me.txtBirthYear.Location = New System.Drawing.Point(1173, 194)
        Me.txtBirthYear.Margin = New System.Windows.Forms.Padding(5)
        Me.txtBirthYear.Name = "txtBirthYear"
        Me.txtBirthYear.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtBirthYear.PlaceholderForeColor = System.Drawing.Color.Black
        Me.txtBirthYear.PlaceholderText = ""
        Me.txtBirthYear.SelectedText = ""
        Me.txtBirthYear.ShadowDecoration.Parent = Me.txtBirthYear
        Me.txtBirthYear.Size = New System.Drawing.Size(545, 55)
        Me.txtBirthYear.TabIndex = 58
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Lucida Sans Unicode", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(1173, 166)
        Me.Guna2HtmlLabel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(167, 22)
        Me.Guna2HtmlLabel2.TabIndex = 57
        Me.Guna2HtmlLabel2.Text = "Input Your Birth year"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label20.Location = New System.Drawing.Point(1369, 85)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(46, 17)
        Me.Label20.TabIndex = 52
        Me.Label20.Text = "Date :"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CalendarMonthBackground = System.Drawing.Color.White
        Me.DateTimePicker1.Enabled = False
        Me.DateTimePicker1.Location = New System.Drawing.Point(1434, 82)
        Me.DateTimePicker1.Margin = New System.Windows.Forms.Padding(4)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(315, 22)
        Me.DateTimePicker1.TabIndex = 51
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label22.Font = New System.Drawing.Font("Lucida Sans Unicode", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.Location = New System.Drawing.Point(1223, 23)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(416, 57)
        Me.Label22.TabIndex = 48
        Me.Label22.Text = "AGE CALCULATOR"
        '
        'Guna2PictureBox8
        '
        Me.Guna2PictureBox8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2PictureBox8.Image = CType(resources.GetObject("Guna2PictureBox8.Image"), System.Drawing.Image)
        Me.Guna2PictureBox8.Location = New System.Drawing.Point(0, -8)
        Me.Guna2PictureBox8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox8.Name = "Guna2PictureBox8"
        Me.Guna2PictureBox8.ShadowDecoration.Parent = Me.Guna2PictureBox8
        Me.Guna2PictureBox8.Size = New System.Drawing.Size(826, 808)
        Me.Guna2PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox8.TabIndex = 47
        Me.Guna2PictureBox8.TabStop = False
        '
        'Guna2GroupBox3
        '
        Me.Guna2GroupBox3.CustomBorderColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Guna2GroupBox3.CustomBorderThickness = New System.Windows.Forms.Padding(0, 29, 0, 0)
        Me.Guna2GroupBox3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Guna2GroupBox3.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox3.Location = New System.Drawing.Point(1152, 553)
        Me.Guna2GroupBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox3.Name = "Guna2GroupBox3"
        Me.Guna2GroupBox3.ShadowDecoration.Parent = Me.Guna2GroupBox3
        Me.Guna2GroupBox3.Size = New System.Drawing.Size(597, 144)
        Me.Guna2GroupBox3.TabIndex = 64
        Me.Guna2GroupBox3.Text = "YOU'ARE"
        '
        'Guna2GroupBox4
        '
        Me.Guna2GroupBox4.Controls.Add(Me.btnCalculateAge)
        Me.Guna2GroupBox4.Controls.Add(Me.ClearButton)
        Me.Guna2GroupBox4.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox4.CustomBorderThickness = New System.Windows.Forms.Padding(0, 30, 0, 0)
        Me.Guna2GroupBox4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox4.Location = New System.Drawing.Point(1152, 119)
        Me.Guna2GroupBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox4.Name = "Guna2GroupBox4"
        Me.Guna2GroupBox4.ShadowDecoration.Parent = Me.Guna2GroupBox4
        Me.Guna2GroupBox4.Size = New System.Drawing.Size(597, 414)
        Me.Guna2GroupBox4.TabIndex = 65
        Me.Guna2GroupBox4.Text = "AGE INFORMATIONS"
        '
        'btnCalculateAge
        '
        Me.btnCalculateAge.BorderRadius = 4
        Me.btnCalculateAge.CheckedState.Parent = Me.btnCalculateAge
        Me.btnCalculateAge.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnCalculateAge.CustomImages.Parent = Me.btnCalculateAge
        Me.btnCalculateAge.FillColor = System.Drawing.SystemColors.HotTrack
        Me.btnCalculateAge.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculateAge.ForeColor = System.Drawing.Color.White
        Me.btnCalculateAge.HoverState.Parent = Me.btnCalculateAge
        Me.btnCalculateAge.Location = New System.Drawing.Point(23, 345)
        Me.btnCalculateAge.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnCalculateAge.Name = "btnCalculateAge"
        Me.btnCalculateAge.ShadowDecoration.Parent = Me.btnCalculateAge
        Me.btnCalculateAge.Size = New System.Drawing.Size(243, 50)
        Me.btnCalculateAge.TabIndex = 59
        Me.btnCalculateAge.Text = " CALCULATE"
        '
        'ClearButton
        '
        Me.ClearButton.BorderRadius = 4
        Me.ClearButton.CheckedState.Parent = Me.ClearButton
        Me.ClearButton.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ClearButton.CustomImages.Parent = Me.ClearButton
        Me.ClearButton.FillColor = System.Drawing.Color.Red
        Me.ClearButton.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearButton.ForeColor = System.Drawing.Color.White
        Me.ClearButton.HoverState.Parent = Me.ClearButton
        Me.ClearButton.Location = New System.Drawing.Point(414, 345)
        Me.ClearButton.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.ShadowDecoration.Parent = Me.ClearButton
        Me.ClearButton.Size = New System.Drawing.Size(153, 50)
        Me.ClearButton.TabIndex = 59
        Me.ClearButton.Text = "CLEAR"
        '
        'Gp_Calcu_Panel2
        '
        Me.Gp_Calcu_Panel2.BackColor = System.Drawing.Color.White
        Me.Gp_Calcu_Panel2.Controls.Add(Me.Guna2GroupBox17)
        Me.Gp_Calcu_Panel2.Controls.Add(Me.first_semester_Panel)
        Me.Gp_Calcu_Panel2.Controls.Add(Me.second_semester_Panel)
        Me.Gp_Calcu_Panel2.Location = New System.Drawing.Point(303, 316)
        Me.Gp_Calcu_Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Gp_Calcu_Panel2.Name = "Gp_Calcu_Panel2"
        Me.Gp_Calcu_Panel2.ShadowDecoration.Parent = Me.Gp_Calcu_Panel2
        Me.Gp_Calcu_Panel2.Size = New System.Drawing.Size(1657, 762)
        Me.Gp_Calcu_Panel2.TabIndex = 10
        '
        'Guna2GroupBox17
        '
        Me.Guna2GroupBox17.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2GroupBox17.BorderColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Guna2GroupBox17.Controls.Add(Me.GroupBox3)
        Me.Guna2GroupBox17.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox17.CustomBorderThickness = New System.Windows.Forms.Padding(0, 45, 0, 0)
        Me.Guna2GroupBox17.FillColor = System.Drawing.Color.Transparent
        Me.Guna2GroupBox17.Font = New System.Drawing.Font("Segoe UI Semibold", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Guna2GroupBox17.Location = New System.Drawing.Point(10, 3)
        Me.Guna2GroupBox17.Name = "Guna2GroupBox17"
        Me.Guna2GroupBox17.ShadowDecoration.Parent = Me.Guna2GroupBox17
        Me.Guna2GroupBox17.Size = New System.Drawing.Size(1598, 138)
        Me.Guna2GroupBox17.TabIndex = 5
        Me.Guna2GroupBox17.Text = "AFOOTECH GLOBAL GRADE POINT CALCULATOR"
        Me.Guna2GroupBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.first_semester_calc_btn)
        Me.GroupBox3.Controls.Add(Me.second_semester_calc_btn)
        Me.GroupBox3.Font = New System.Drawing.Font("Candara", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(507, 53)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(619, 81)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Select Semester To Calculate"
        '
        'first_semester_calc_btn
        '
        Me.first_semester_calc_btn.BorderRadius = 4
        Me.first_semester_calc_btn.CheckedState.Parent = Me.first_semester_calc_btn
        Me.first_semester_calc_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.first_semester_calc_btn.CustomImages.Parent = Me.first_semester_calc_btn
        Me.first_semester_calc_btn.FillColor = System.Drawing.SystemColors.HotTrack
        Me.first_semester_calc_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.first_semester_calc_btn.ForeColor = System.Drawing.Color.White
        Me.first_semester_calc_btn.HoverState.Parent = Me.first_semester_calc_btn
        Me.first_semester_calc_btn.Location = New System.Drawing.Point(50, 22)
        Me.first_semester_calc_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.first_semester_calc_btn.Name = "first_semester_calc_btn"
        Me.first_semester_calc_btn.ShadowDecoration.Parent = Me.first_semester_calc_btn
        Me.first_semester_calc_btn.Size = New System.Drawing.Size(244, 48)
        Me.first_semester_calc_btn.TabIndex = 39
        Me.first_semester_calc_btn.Text = "FIRST SEMESTER"
        '
        'second_semester_calc_btn
        '
        Me.second_semester_calc_btn.BorderRadius = 4
        Me.second_semester_calc_btn.CheckedState.Parent = Me.second_semester_calc_btn
        Me.second_semester_calc_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.second_semester_calc_btn.CustomImages.Parent = Me.second_semester_calc_btn
        Me.second_semester_calc_btn.FillColor = System.Drawing.SystemColors.HotTrack
        Me.second_semester_calc_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.second_semester_calc_btn.ForeColor = System.Drawing.Color.White
        Me.second_semester_calc_btn.HoverState.Parent = Me.second_semester_calc_btn
        Me.second_semester_calc_btn.Location = New System.Drawing.Point(329, 21)
        Me.second_semester_calc_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.second_semester_calc_btn.Name = "second_semester_calc_btn"
        Me.second_semester_calc_btn.ShadowDecoration.Parent = Me.second_semester_calc_btn
        Me.second_semester_calc_btn.Size = New System.Drawing.Size(244, 48)
        Me.second_semester_calc_btn.TabIndex = 39
        Me.second_semester_calc_btn.Text = "SECOND SEMESTER"
        '
        'first_semester_Panel
        '
        Me.first_semester_Panel.BackColor = System.Drawing.Color.White
        Me.first_semester_Panel.Controls.Add(Me.Guna2GroupBox13)
        Me.first_semester_Panel.Controls.Add(Me.GroupBox11)
        Me.first_semester_Panel.Controls.Add(Me.Guna2TextBox10)
        Me.first_semester_Panel.Controls.Add(Me.Guna2TextBox11)
        Me.first_semester_Panel.Controls.Add(Me.Guna2TextBox12)
        Me.first_semester_Panel.Controls.Add(Me.Guna2TextBox13)
        Me.first_semester_Panel.Location = New System.Drawing.Point(12, 145)
        Me.first_semester_Panel.Name = "first_semester_Panel"
        Me.first_semester_Panel.ShadowDecoration.Parent = Me.first_semester_Panel
        Me.first_semester_Panel.Size = New System.Drawing.Size(1907, 617)
        Me.first_semester_Panel.TabIndex = 56
        '
        'Guna2GroupBox13
        '
        Me.Guna2GroupBox13.Controls.Add(Me.Label56)
        Me.Guna2GroupBox13.Controls.Add(Me.Label57)
        Me.Guna2GroupBox13.Controls.Add(Me.Label58)
        Me.Guna2GroupBox13.Controls.Add(Me.Label59)
        Me.Guna2GroupBox13.Controls.Add(Me.TotalGPFirst_txt)
        Me.Guna2GroupBox13.Controls.Add(Me.GPAFirst_txt)
        Me.Guna2GroupBox13.Controls.Add(Me.GradeClassFirst_txt)
        Me.Guna2GroupBox13.Controls.Add(Me.txtCourseUnitsFirst)
        Me.Guna2GroupBox13.Controls.Add(Me.ClearFirst_btn)
        Me.Guna2GroupBox13.Controls.Add(Me.calcFirst_btn)
        Me.Guna2GroupBox13.CustomBorderThickness = New System.Windows.Forms.Padding(0)
        Me.Guna2GroupBox13.FillColor = System.Drawing.Color.WhiteSmoke
        Me.Guna2GroupBox13.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2GroupBox13.Location = New System.Drawing.Point(3, 411)
        Me.Guna2GroupBox13.Name = "Guna2GroupBox13"
        Me.Guna2GroupBox13.ShadowDecoration.Parent = Me.Guna2GroupBox13
        Me.Guna2GroupBox13.Size = New System.Drawing.Size(1605, 182)
        Me.Guna2GroupBox13.TabIndex = 92
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label56.Font = New System.Drawing.Font("Segoe UI Semilight", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label56.ForeColor = System.Drawing.Color.Black
        Me.Label56.Location = New System.Drawing.Point(274, 56)
        Me.Label56.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(193, 23)
        Me.Label56.TabIndex = 86
        Me.Label56.Text = "TOTAL COURSE UNITS"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label57.Font = New System.Drawing.Font("Segoe UI Semilight", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label57.ForeColor = System.Drawing.Color.Black
        Me.Label57.Location = New System.Drawing.Point(1246, 57)
        Me.Label57.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(212, 23)
        Me.Label57.TabIndex = 85
        Me.Label57.Text = "GRADE CLASSIFICATION"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label58.Font = New System.Drawing.Font("Segoe UI Semilight", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label58.ForeColor = System.Drawing.Color.Black
        Me.Label58.Location = New System.Drawing.Point(581, 56)
        Me.Label58.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(211, 23)
        Me.Label58.TabIndex = 84
        Me.Label58.Text = "GRADE POINT AVERAGE"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label59.Font = New System.Drawing.Font("Segoe UI Semilight", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label59.ForeColor = System.Drawing.Color.Black
        Me.Label59.Location = New System.Drawing.Point(929, 56)
        Me.Label59.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(195, 23)
        Me.Label59.TabIndex = 83
        Me.Label59.Text = "TOTAL GRADE POINTS"
        '
        'TotalGPFirst_txt
        '
        Me.TotalGPFirst_txt.BorderColor = System.Drawing.Color.White
        Me.TotalGPFirst_txt.BorderRadius = 3
        Me.TotalGPFirst_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalGPFirst_txt.DefaultText = ""
        Me.TotalGPFirst_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalGPFirst_txt.DisabledState.FillColor = System.Drawing.Color.White
        Me.TotalGPFirst_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalGPFirst_txt.DisabledState.Parent = Me.TotalGPFirst_txt
        Me.TotalGPFirst_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalGPFirst_txt.Enabled = False
        Me.TotalGPFirst_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalGPFirst_txt.FocusedState.Parent = Me.TotalGPFirst_txt
        Me.TotalGPFirst_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalGPFirst_txt.HoverState.Parent = Me.TotalGPFirst_txt
        Me.TotalGPFirst_txt.Location = New System.Drawing.Point(933, 101)
        Me.TotalGPFirst_txt.Margin = New System.Windows.Forms.Padding(21, 32, 21, 32)
        Me.TotalGPFirst_txt.Name = "TotalGPFirst_txt"
        Me.TotalGPFirst_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalGPFirst_txt.PlaceholderText = ""
        Me.TotalGPFirst_txt.SelectedText = ""
        Me.TotalGPFirst_txt.ShadowDecoration.Parent = Me.TotalGPFirst_txt
        Me.TotalGPFirst_txt.Size = New System.Drawing.Size(250, 62)
        Me.TotalGPFirst_txt.TabIndex = 81
        '
        'GPAFirst_txt
        '
        Me.GPAFirst_txt.BorderColor = System.Drawing.Color.White
        Me.GPAFirst_txt.BorderRadius = 3
        Me.GPAFirst_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GPAFirst_txt.DefaultText = ""
        Me.GPAFirst_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.GPAFirst_txt.DisabledState.FillColor = System.Drawing.Color.White
        Me.GPAFirst_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.GPAFirst_txt.DisabledState.Parent = Me.GPAFirst_txt
        Me.GPAFirst_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.GPAFirst_txt.Enabled = False
        Me.GPAFirst_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GPAFirst_txt.FocusedState.Parent = Me.GPAFirst_txt
        Me.GPAFirst_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GPAFirst_txt.HoverState.Parent = Me.GPAFirst_txt
        Me.GPAFirst_txt.Location = New System.Drawing.Point(589, 101)
        Me.GPAFirst_txt.Margin = New System.Windows.Forms.Padding(12, 24, 12, 24)
        Me.GPAFirst_txt.Name = "GPAFirst_txt"
        Me.GPAFirst_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GPAFirst_txt.PlaceholderText = ""
        Me.GPAFirst_txt.SelectedText = ""
        Me.GPAFirst_txt.ShadowDecoration.Parent = Me.GPAFirst_txt
        Me.GPAFirst_txt.Size = New System.Drawing.Size(231, 62)
        Me.GPAFirst_txt.TabIndex = 82
        '
        'GradeClassFirst_txt
        '
        Me.GradeClassFirst_txt.BorderColor = System.Drawing.Color.White
        Me.GradeClassFirst_txt.BorderRadius = 3
        Me.GradeClassFirst_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GradeClassFirst_txt.DefaultText = ""
        Me.GradeClassFirst_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.GradeClassFirst_txt.DisabledState.FillColor = System.Drawing.Color.White
        Me.GradeClassFirst_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.GradeClassFirst_txt.DisabledState.Parent = Me.GradeClassFirst_txt
        Me.GradeClassFirst_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.GradeClassFirst_txt.Enabled = False
        Me.GradeClassFirst_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GradeClassFirst_txt.FocusedState.Parent = Me.GradeClassFirst_txt
        Me.GradeClassFirst_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GradeClassFirst_txt.HoverState.Parent = Me.GradeClassFirst_txt
        Me.GradeClassFirst_txt.Location = New System.Drawing.Point(1253, 106)
        Me.GradeClassFirst_txt.Margin = New System.Windows.Forms.Padding(12, 24, 12, 24)
        Me.GradeClassFirst_txt.Name = "GradeClassFirst_txt"
        Me.GradeClassFirst_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GradeClassFirst_txt.PlaceholderText = ""
        Me.GradeClassFirst_txt.SelectedText = ""
        Me.GradeClassFirst_txt.ShadowDecoration.Parent = Me.GradeClassFirst_txt
        Me.GradeClassFirst_txt.Size = New System.Drawing.Size(290, 59)
        Me.GradeClassFirst_txt.TabIndex = 80
        '
        'txtCourseUnitsFirst
        '
        Me.txtCourseUnitsFirst.BorderColor = System.Drawing.Color.White
        Me.txtCourseUnitsFirst.BorderRadius = 3
        Me.txtCourseUnitsFirst.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtCourseUnitsFirst.DefaultText = ""
        Me.txtCourseUnitsFirst.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtCourseUnitsFirst.DisabledState.FillColor = System.Drawing.Color.White
        Me.txtCourseUnitsFirst.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtCourseUnitsFirst.DisabledState.Parent = Me.txtCourseUnitsFirst
        Me.txtCourseUnitsFirst.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtCourseUnitsFirst.Enabled = False
        Me.txtCourseUnitsFirst.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCourseUnitsFirst.FocusedState.Parent = Me.txtCourseUnitsFirst
        Me.txtCourseUnitsFirst.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtCourseUnitsFirst.HoverState.Parent = Me.txtCourseUnitsFirst
        Me.txtCourseUnitsFirst.Location = New System.Drawing.Point(276, 101)
        Me.txtCourseUnitsFirst.Margin = New System.Windows.Forms.Padding(7, 14, 7, 14)
        Me.txtCourseUnitsFirst.Name = "txtCourseUnitsFirst"
        Me.txtCourseUnitsFirst.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtCourseUnitsFirst.PlaceholderText = ""
        Me.txtCourseUnitsFirst.SelectedText = ""
        Me.txtCourseUnitsFirst.ShadowDecoration.Parent = Me.txtCourseUnitsFirst
        Me.txtCourseUnitsFirst.Size = New System.Drawing.Size(232, 62)
        Me.txtCourseUnitsFirst.TabIndex = 79
        '
        'ClearFirst_btn
        '
        Me.ClearFirst_btn.BorderRadius = 4
        Me.ClearFirst_btn.CheckedState.Parent = Me.ClearFirst_btn
        Me.ClearFirst_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ClearFirst_btn.CustomImages.Parent = Me.ClearFirst_btn
        Me.ClearFirst_btn.FillColor = System.Drawing.Color.Red
        Me.ClearFirst_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearFirst_btn.ForeColor = System.Drawing.Color.White
        Me.ClearFirst_btn.HoverState.Parent = Me.ClearFirst_btn
        Me.ClearFirst_btn.Location = New System.Drawing.Point(27, 106)
        Me.ClearFirst_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ClearFirst_btn.Name = "ClearFirst_btn"
        Me.ClearFirst_btn.ShadowDecoration.Parent = Me.ClearFirst_btn
        Me.ClearFirst_btn.Size = New System.Drawing.Size(221, 57)
        Me.ClearFirst_btn.TabIndex = 77
        Me.ClearFirst_btn.Text = "CLEAR"
        '
        'calcFirst_btn
        '
        Me.calcFirst_btn.BorderRadius = 4
        Me.calcFirst_btn.CheckedState.Parent = Me.calcFirst_btn
        Me.calcFirst_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.calcFirst_btn.CustomImages.Parent = Me.calcFirst_btn
        Me.calcFirst_btn.FillColor = System.Drawing.SystemColors.HotTrack
        Me.calcFirst_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calcFirst_btn.ForeColor = System.Drawing.Color.White
        Me.calcFirst_btn.HoverState.Parent = Me.calcFirst_btn
        Me.calcFirst_btn.Location = New System.Drawing.Point(27, 19)
        Me.calcFirst_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.calcFirst_btn.Name = "calcFirst_btn"
        Me.calcFirst_btn.ShadowDecoration.Parent = Me.calcFirst_btn
        Me.calcFirst_btn.Size = New System.Drawing.Size(221, 67)
        Me.calcFirst_btn.TabIndex = 78
        Me.calcFirst_btn.Text = "CALCULATE"
        '
        'GroupBox11
        '
        Me.GroupBox11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox11.Controls.Add(Me.Label60)
        Me.GroupBox11.Controls.Add(Me.Label10)
        Me.GroupBox11.Controls.Add(Me.Label61)
        Me.GroupBox11.Controls.Add(Me.Label9)
        Me.GroupBox11.Controls.Add(Me.Label62)
        Me.GroupBox11.Controls.Add(Me.Label8)
        Me.GroupBox11.Controls.Add(Me.Label63)
        Me.GroupBox11.Controls.Add(Me.Label7)
        Me.GroupBox11.Controls.Add(Me.Label64)
        Me.GroupBox11.Controls.Add(Me.AGD106_txt)
        Me.GroupBox11.Controls.Add(Me.Label65)
        Me.GroupBox11.Controls.Add(Me.Label1)
        Me.GroupBox11.Controls.Add(Me.NS105_txt)
        Me.GroupBox11.Controls.Add(Me.Label66)
        Me.GroupBox11.Controls.Add(Me.WAD104_txt)
        Me.GroupBox11.Controls.Add(Me.Label2)
        Me.GroupBox11.Controls.Add(Me.MAD102_txt)
        Me.GroupBox11.Controls.Add(Me.Label67)
        Me.GroupBox11.Controls.Add(Me.SDA103_txt)
        Me.GroupBox11.Controls.Add(Me.Label3)
        Me.GroupBox11.Controls.Add(Me.SDT101_txt)
        Me.GroupBox11.Controls.Add(Me.Label68)
        Me.GroupBox11.Controls.Add(Me.Label4)
        Me.GroupBox11.Controls.Add(Me.Label69)
        Me.GroupBox11.Controls.Add(Me.Label5)
        Me.GroupBox11.Controls.Add(Me.Label70)
        Me.GroupBox11.Controls.Add(Me.Label6)
        Me.GroupBox11.Controls.Add(Me.Label71)
        Me.GroupBox11.Location = New System.Drawing.Point(4, 11)
        Me.GroupBox11.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox11.Size = New System.Drawing.Size(1593, 388)
        Me.GroupBox11.TabIndex = 76
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "Course Details"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Segoe UI Semilight", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.Location = New System.Drawing.Point(1369, 337)
        Me.Label60.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(89, 25)
        Me.Label60.TabIndex = 11
        Me.Label60.Text = "(4 UNIT)"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(1358, 25)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(125, 25)
        Me.Label10.TabIndex = 33
        Me.Label10.Text = "Course Units"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Segoe UI Semilight", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.Location = New System.Drawing.Point(1369, 282)
        Me.Label61.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(89, 25)
        Me.Label61.TabIndex = 10
        Me.Label61.Text = "(4 UNIT)"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(995, 20)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 25)
        Me.Label9.TabIndex = 32
        Me.Label9.Text = "Scores"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Segoe UI Semilight", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.Location = New System.Drawing.Point(1369, 229)
        Me.Label62.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(89, 25)
        Me.Label62.TabIndex = 9
        Me.Label62.Text = "(4 UNIT)"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(638, 24)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(129, 25)
        Me.Label8.TabIndex = 31
        Me.Label8.Text = "Course Code"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Segoe UI Semilight", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.Location = New System.Drawing.Point(1369, 174)
        Me.Label63.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(89, 25)
        Me.Label63.TabIndex = 8
        Me.Label63.Text = "(5 UNIT)"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(29, 25)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(118, 25)
        Me.Label7.TabIndex = 30
        Me.Label7.Text = "Course Title"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Segoe UI Semilight", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.Location = New System.Drawing.Point(1370, 124)
        Me.Label64.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(89, 25)
        Me.Label64.TabIndex = 7
        Me.Label64.Text = "(4 UNIT)"
        '
        'AGD106_txt
        '
        Me.AGD106_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AGD106_txt.Location = New System.Drawing.Point(877, 325)
        Me.AGD106_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.AGD106_txt.Multiline = True
        Me.AGD106_txt.Name = "AGD106_txt"
        Me.AGD106_txt.Size = New System.Drawing.Size(368, 37)
        Me.AGD106_txt.TabIndex = 29
        Me.AGD106_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Segoe UI Semilight", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.Location = New System.Drawing.Point(1367, 73)
        Me.Label65.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(89, 25)
        Me.Label65.TabIndex = 6
        Me.Label65.Text = "(4 UNIT)"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(638, 340)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(103, 28)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "(AGD 106)"
        '
        'NS105_txt
        '
        Me.NS105_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NS105_txt.Location = New System.Drawing.Point(877, 275)
        Me.NS105_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.NS105_txt.Multiline = True
        Me.NS105_txt.Name = "NS105_txt"
        Me.NS105_txt.Size = New System.Drawing.Size(368, 37)
        Me.NS105_txt.TabIndex = 28
        Me.NS105_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.Location = New System.Drawing.Point(29, 335)
        Me.Label66.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(383, 28)
        Me.Label66.TabIndex = 5
        Me.Label66.Text = "Input score for Advance Graphics Design"
        '
        'WAD104_txt
        '
        Me.WAD104_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.WAD104_txt.Location = New System.Drawing.Point(877, 221)
        Me.WAD104_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.WAD104_txt.Multiline = True
        Me.WAD104_txt.Name = "WAD104_txt"
        Me.WAD104_txt.Size = New System.Drawing.Size(368, 37)
        Me.WAD104_txt.TabIndex = 27
        Me.WAD104_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(642, 287)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(88, 28)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "(NS 105)"
        '
        'MAD102_txt
        '
        Me.MAD102_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MAD102_txt.Location = New System.Drawing.Point(877, 117)
        Me.MAD102_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.MAD102_txt.Multiline = True
        Me.MAD102_txt.Name = "MAD102_txt"
        Me.MAD102_txt.Size = New System.Drawing.Size(368, 37)
        Me.MAD102_txt.TabIndex = 26
        Me.MAD102_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.Location = New System.Drawing.Point(29, 118)
        Me.Label67.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(453, 28)
        Me.Label67.TabIndex = 4
        Me.Label67.Text = "Input score for Mobile Application Development"
        '
        'SDA103_txt
        '
        Me.SDA103_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SDA103_txt.Location = New System.Drawing.Point(877, 171)
        Me.SDA103_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.SDA103_txt.Multiline = True
        Me.SDA103_txt.Name = "SDA103_txt"
        Me.SDA103_txt.Size = New System.Drawing.Size(368, 37)
        Me.SDA103_txt.TabIndex = 25
        Me.SDA103_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(638, 229)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(108, 28)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "(WAD 104)"
        '
        'SDT101_txt
        '
        Me.SDT101_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SDT101_txt.Location = New System.Drawing.Point(877, 66)
        Me.SDT101_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.SDT101_txt.Multiline = True
        Me.SDT101_txt.Name = "SDT101_txt"
        Me.SDT101_txt.Size = New System.Drawing.Size(368, 37)
        Me.SDT101_txt.TabIndex = 24
        Me.SDT101_txt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.Location = New System.Drawing.Point(29, 172)
        Me.Label68.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(388, 28)
        Me.Label68.TabIndex = 3
        Me.Label68.Text = "Input score for System And Data Analysis"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(638, 177)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 28)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "(SDA 103)"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.Location = New System.Drawing.Point(29, 226)
        Me.Label69.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(463, 28)
        Me.Label69.TabIndex = 2
        Me.Label69.Text = "Input score for Website Application Development"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(639, 123)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 28)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "(MAD 102)"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.Location = New System.Drawing.Point(29, 282)
        Me.Label70.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(353, 28)
        Me.Label70.TabIndex = 1
        Me.Label70.Text = "Input score for Network And Sucurity"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(635, 63)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 28)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "(SDT 101)"
        '
        'Label71
        '
        Me.Label71.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.Location = New System.Drawing.Point(29, 65)
        Me.Label71.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(446, 28)
        Me.Label71.TabIndex = 0
        Me.Label71.Text = "Input score for Software Development Training "
        '
        'Guna2TextBox10
        '
        Me.Guna2TextBox10.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox10.DefaultText = ""
        Me.Guna2TextBox10.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox10.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox10.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox10.DisabledState.Parent = Me.Guna2TextBox10
        Me.Guna2TextBox10.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox10.Enabled = False
        Me.Guna2TextBox10.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox10.FocusedState.Parent = Me.Guna2TextBox10
        Me.Guna2TextBox10.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox10.HoverState.Parent = Me.Guna2TextBox10
        Me.Guna2TextBox10.Location = New System.Drawing.Point(2378, 1765)
        Me.Guna2TextBox10.Margin = New System.Windows.Forms.Padding(69, 72, 69, 72)
        Me.Guna2TextBox10.Name = "Guna2TextBox10"
        Me.Guna2TextBox10.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox10.PlaceholderText = ""
        Me.Guna2TextBox10.SelectedText = ""
        Me.Guna2TextBox10.ShadowDecoration.Parent = Me.Guna2TextBox10
        Me.Guna2TextBox10.Size = New System.Drawing.Size(758, 149)
        Me.Guna2TextBox10.TabIndex = 70
        '
        'Guna2TextBox11
        '
        Me.Guna2TextBox11.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox11.DefaultText = ""
        Me.Guna2TextBox11.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox11.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox11.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox11.DisabledState.Parent = Me.Guna2TextBox11
        Me.Guna2TextBox11.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox11.Enabled = False
        Me.Guna2TextBox11.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox11.FocusedState.Parent = Me.Guna2TextBox11
        Me.Guna2TextBox11.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox11.HoverState.Parent = Me.Guna2TextBox11
        Me.Guna2TextBox11.Location = New System.Drawing.Point(1294, 1765)
        Me.Guna2TextBox11.Margin = New System.Windows.Forms.Padding(39, 41, 39, 41)
        Me.Guna2TextBox11.Name = "Guna2TextBox11"
        Me.Guna2TextBox11.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox11.PlaceholderText = ""
        Me.Guna2TextBox11.SelectedText = ""
        Me.Guna2TextBox11.ShadowDecoration.Parent = Me.Guna2TextBox11
        Me.Guna2TextBox11.Size = New System.Drawing.Size(758, 149)
        Me.Guna2TextBox11.TabIndex = 71
        '
        'Guna2TextBox12
        '
        Me.Guna2TextBox12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox12.DefaultText = ""
        Me.Guna2TextBox12.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox12.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox12.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox12.DisabledState.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox12.Enabled = False
        Me.Guna2TextBox12.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox12.FocusedState.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox12.HoverState.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.Location = New System.Drawing.Point(2378, 1480)
        Me.Guna2TextBox12.Margin = New System.Windows.Forms.Padding(39, 41, 39, 41)
        Me.Guna2TextBox12.Name = "Guna2TextBox12"
        Me.Guna2TextBox12.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox12.PlaceholderText = ""
        Me.Guna2TextBox12.SelectedText = ""
        Me.Guna2TextBox12.ShadowDecoration.Parent = Me.Guna2TextBox12
        Me.Guna2TextBox12.Size = New System.Drawing.Size(739, 149)
        Me.Guna2TextBox12.TabIndex = 68
        '
        'Guna2TextBox13
        '
        Me.Guna2TextBox13.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Guna2TextBox13.DefaultText = ""
        Me.Guna2TextBox13.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Guna2TextBox13.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2TextBox13.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox13.DisabledState.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Guna2TextBox13.Enabled = False
        Me.Guna2TextBox13.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox13.FocusedState.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Guna2TextBox13.HoverState.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.Location = New System.Drawing.Point(1281, 1480)
        Me.Guna2TextBox13.Margin = New System.Windows.Forms.Padding(22, 23, 22, 23)
        Me.Guna2TextBox13.Name = "Guna2TextBox13"
        Me.Guna2TextBox13.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Guna2TextBox13.PlaceholderText = ""
        Me.Guna2TextBox13.SelectedText = ""
        Me.Guna2TextBox13.ShadowDecoration.Parent = Me.Guna2TextBox13
        Me.Guna2TextBox13.Size = New System.Drawing.Size(748, 155)
        Me.Guna2TextBox13.TabIndex = 69
        '
        'second_semester_Panel
        '
        Me.second_semester_Panel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.second_semester_Panel.BackColor = System.Drawing.Color.White
        Me.second_semester_Panel.Controls.Add(Me.Guna2GroupBox16)
        Me.second_semester_Panel.Controls.Add(Me.GroupBox9)
        Me.second_semester_Panel.Location = New System.Drawing.Point(10, 99)
        Me.second_semester_Panel.Margin = New System.Windows.Forms.Padding(4)
        Me.second_semester_Panel.Name = "second_semester_Panel"
        Me.second_semester_Panel.Size = New System.Drawing.Size(1601, 655)
        Me.second_semester_Panel.TabIndex = 89
        '
        'Guna2GroupBox16
        '
        Me.Guna2GroupBox16.Controls.Add(Me.Label52)
        Me.Guna2GroupBox16.Controls.Add(Me.GradeClassSecond_txt)
        Me.Guna2GroupBox16.Controls.Add(Me.Label53)
        Me.Guna2GroupBox16.Controls.Add(Me.TotalGPSecond_txt)
        Me.Guna2GroupBox16.Controls.Add(Me.calcSecond_btn)
        Me.Guna2GroupBox16.Controls.Add(Me.Label51)
        Me.Guna2GroupBox16.Controls.Add(Me.ClearSecond_btn)
        Me.Guna2GroupBox16.Controls.Add(Me.Label37)
        Me.Guna2GroupBox16.Controls.Add(Me.TotalGPASecond_txt)
        Me.Guna2GroupBox16.Controls.Add(Me.txtTotalCourseUnits2)
        Me.Guna2GroupBox16.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox16.FillColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox16.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2GroupBox16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2GroupBox16.Location = New System.Drawing.Point(0, 461)
        Me.Guna2GroupBox16.Name = "Guna2GroupBox16"
        Me.Guna2GroupBox16.ShadowDecoration.Parent = Me.Guna2GroupBox16
        Me.Guna2GroupBox16.Size = New System.Drawing.Size(1898, 178)
        Me.Guna2GroupBox16.TabIndex = 54
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label52.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label52.ForeColor = System.Drawing.Color.Black
        Me.Label52.Location = New System.Drawing.Point(1283, 51)
        Me.Label52.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(198, 23)
        Me.Label52.TabIndex = 87
        Me.Label52.Text = "GRADE CLASSIFICATION"
        '
        'GradeClassSecond_txt
        '
        Me.GradeClassSecond_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.GradeClassSecond_txt.DefaultText = ""
        Me.GradeClassSecond_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.GradeClassSecond_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.GradeClassSecond_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.GradeClassSecond_txt.DisabledState.Parent = Me.GradeClassSecond_txt
        Me.GradeClassSecond_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.GradeClassSecond_txt.Enabled = False
        Me.GradeClassSecond_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GradeClassSecond_txt.FocusedState.Parent = Me.GradeClassSecond_txt
        Me.GradeClassSecond_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GradeClassSecond_txt.HoverState.Parent = Me.GradeClassSecond_txt
        Me.GradeClassSecond_txt.Location = New System.Drawing.Point(1287, 91)
        Me.GradeClassSecond_txt.Margin = New System.Windows.Forms.Padding(11, 18, 11, 18)
        Me.GradeClassSecond_txt.Name = "GradeClassSecond_txt"
        Me.GradeClassSecond_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.GradeClassSecond_txt.PlaceholderText = ""
        Me.GradeClassSecond_txt.SelectedText = ""
        Me.GradeClassSecond_txt.ShadowDecoration.Parent = Me.GradeClassSecond_txt
        Me.GradeClassSecond_txt.Size = New System.Drawing.Size(290, 65)
        Me.GradeClassSecond_txt.TabIndex = 53
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label53.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label53.ForeColor = System.Drawing.Color.Black
        Me.Label53.Location = New System.Drawing.Point(982, 54)
        Me.Label53.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(181, 23)
        Me.Label53.TabIndex = 86
        Me.Label53.Text = "TOTAL GRADE POINTS"
        '
        'TotalGPSecond_txt
        '
        Me.TotalGPSecond_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalGPSecond_txt.DefaultText = ""
        Me.TotalGPSecond_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalGPSecond_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TotalGPSecond_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalGPSecond_txt.DisabledState.Parent = Me.TotalGPSecond_txt
        Me.TotalGPSecond_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalGPSecond_txt.Enabled = False
        Me.TotalGPSecond_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalGPSecond_txt.FocusedState.Parent = Me.TotalGPSecond_txt
        Me.TotalGPSecond_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalGPSecond_txt.HoverState.Parent = Me.TotalGPSecond_txt
        Me.TotalGPSecond_txt.Location = New System.Drawing.Point(986, 94)
        Me.TotalGPSecond_txt.Margin = New System.Windows.Forms.Padding(6, 10, 6, 10)
        Me.TotalGPSecond_txt.Name = "TotalGPSecond_txt"
        Me.TotalGPSecond_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalGPSecond_txt.PlaceholderText = ""
        Me.TotalGPSecond_txt.SelectedText = ""
        Me.TotalGPSecond_txt.ShadowDecoration.Parent = Me.TotalGPSecond_txt
        Me.TotalGPSecond_txt.Size = New System.Drawing.Size(232, 62)
        Me.TotalGPSecond_txt.TabIndex = 52
        '
        'calcSecond_btn
        '
        Me.calcSecond_btn.BorderRadius = 4
        Me.calcSecond_btn.CheckedState.Parent = Me.calcSecond_btn
        Me.calcSecond_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.calcSecond_btn.CustomImages.Parent = Me.calcSecond_btn
        Me.calcSecond_btn.FillColor = System.Drawing.SystemColors.HotTrack
        Me.calcSecond_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.calcSecond_btn.ForeColor = System.Drawing.Color.White
        Me.calcSecond_btn.HoverState.Parent = Me.calcSecond_btn
        Me.calcSecond_btn.Location = New System.Drawing.Point(95, 15)
        Me.calcSecond_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.calcSecond_btn.Name = "calcSecond_btn"
        Me.calcSecond_btn.ShadowDecoration.Parent = Me.calcSecond_btn
        Me.calcSecond_btn.Size = New System.Drawing.Size(221, 67)
        Me.calcSecond_btn.TabIndex = 38
        Me.calcSecond_btn.Text = "CALCULATE"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label51.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label51.ForeColor = System.Drawing.Color.Black
        Me.Label51.Location = New System.Drawing.Point(667, 52)
        Me.Label51.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(198, 23)
        Me.Label51.TabIndex = 85
        Me.Label51.Text = "GRADE POINT AVERAGE"
        '
        'ClearSecond_btn
        '
        Me.ClearSecond_btn.BorderRadius = 4
        Me.ClearSecond_btn.CheckedState.Parent = Me.ClearSecond_btn
        Me.ClearSecond_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ClearSecond_btn.CustomImages.Parent = Me.ClearSecond_btn
        Me.ClearSecond_btn.FillColor = System.Drawing.Color.Red
        Me.ClearSecond_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ClearSecond_btn.ForeColor = System.Drawing.Color.White
        Me.ClearSecond_btn.HoverState.Parent = Me.ClearSecond_btn
        Me.ClearSecond_btn.Location = New System.Drawing.Point(95, 102)
        Me.ClearSecond_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.ClearSecond_btn.Name = "ClearSecond_btn"
        Me.ClearSecond_btn.ShadowDecoration.Parent = Me.ClearSecond_btn
        Me.ClearSecond_btn.Size = New System.Drawing.Size(221, 57)
        Me.ClearSecond_btn.TabIndex = 38
        Me.ClearSecond_btn.Text = "CLEAR"
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Label37.Font = New System.Drawing.Font("Segoe UI Semibold", 10.0!, System.Drawing.FontStyle.Bold)
        Me.Label37.ForeColor = System.Drawing.Color.Black
        Me.Label37.Location = New System.Drawing.Point(378, 56)
        Me.Label37.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(180, 23)
        Me.Label37.TabIndex = 36
        Me.Label37.Text = "TOTAL COURSE UNITS"
        '
        'TotalGPASecond_txt
        '
        Me.TotalGPASecond_txt.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalGPASecond_txt.DefaultText = ""
        Me.TotalGPASecond_txt.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TotalGPASecond_txt.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TotalGPASecond_txt.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalGPASecond_txt.DisabledState.Parent = Me.TotalGPASecond_txt
        Me.TotalGPASecond_txt.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TotalGPASecond_txt.Enabled = False
        Me.TotalGPASecond_txt.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalGPASecond_txt.FocusedState.Parent = Me.TotalGPASecond_txt
        Me.TotalGPASecond_txt.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TotalGPASecond_txt.HoverState.Parent = Me.TotalGPASecond_txt
        Me.TotalGPASecond_txt.Location = New System.Drawing.Point(671, 94)
        Me.TotalGPASecond_txt.Margin = New System.Windows.Forms.Padding(4, 8, 4, 8)
        Me.TotalGPASecond_txt.Name = "TotalGPASecond_txt"
        Me.TotalGPASecond_txt.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TotalGPASecond_txt.PlaceholderText = ""
        Me.TotalGPASecond_txt.SelectedText = ""
        Me.TotalGPASecond_txt.ShadowDecoration.Parent = Me.TotalGPASecond_txt
        Me.TotalGPASecond_txt.Size = New System.Drawing.Size(226, 62)
        Me.TotalGPASecond_txt.TabIndex = 52
        '
        'txtTotalCourseUnits2
        '
        Me.txtTotalCourseUnits2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtTotalCourseUnits2.DefaultText = ""
        Me.txtTotalCourseUnits2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txtTotalCourseUnits2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txtTotalCourseUnits2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTotalCourseUnits2.DisabledState.Parent = Me.txtTotalCourseUnits2
        Me.txtTotalCourseUnits2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txtTotalCourseUnits2.Enabled = False
        Me.txtTotalCourseUnits2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTotalCourseUnits2.FocusedState.Parent = Me.txtTotalCourseUnits2
        Me.txtTotalCourseUnits2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txtTotalCourseUnits2.HoverState.Parent = Me.txtTotalCourseUnits2
        Me.txtTotalCourseUnits2.Location = New System.Drawing.Point(382, 94)
        Me.txtTotalCourseUnits2.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.txtTotalCourseUnits2.Name = "txtTotalCourseUnits2"
        Me.txtTotalCourseUnits2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txtTotalCourseUnits2.PlaceholderText = ""
        Me.txtTotalCourseUnits2.SelectedText = ""
        Me.txtTotalCourseUnits2.ShadowDecoration.Parent = Me.txtTotalCourseUnits2
        Me.txtTotalCourseUnits2.Size = New System.Drawing.Size(220, 65)
        Me.txtTotalCourseUnits2.TabIndex = 52
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.Label11)
        Me.GroupBox9.Controls.Add(Me.Label12)
        Me.GroupBox9.Controls.Add(Me.Label13)
        Me.GroupBox9.Controls.Add(Me.Label14)
        Me.GroupBox9.Controls.Add(Me.DevOp207_txt)
        Me.GroupBox9.Controls.Add(Me.Label19)
        Me.GroupBox9.Controls.Add(Me.DBMS201_txt)
        Me.GroupBox9.Controls.Add(Me.Label28)
        Me.GroupBox9.Controls.Add(Me.AI204_txt)
        Me.GroupBox9.Controls.Add(Me.Label21)
        Me.GroupBox9.Controls.Add(Me.AA206_txt)
        Me.GroupBox9.Controls.Add(Me.Label45)
        Me.GroupBox9.Controls.Add(Me.UIUX202_txt)
        Me.GroupBox9.Controls.Add(Me.SQT205_txt)
        Me.GroupBox9.Controls.Add(Me.Label23)
        Me.GroupBox9.Controls.Add(Me.Label29)
        Me.GroupBox9.Controls.Add(Me.Label24)
        Me.GroupBox9.Controls.Add(Me.Label30)
        Me.GroupBox9.Controls.Add(Me.Label25)
        Me.GroupBox9.Controls.Add(Me.Label46)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.Label27)
        Me.GroupBox9.Controls.Add(Me.Label47)
        Me.GroupBox9.Controls.Add(Me.Label31)
        Me.GroupBox9.Controls.Add(Me.Label48)
        Me.GroupBox9.Controls.Add(Me.Label32)
        Me.GroupBox9.Controls.Add(Me.Label49)
        Me.GroupBox9.Controls.Add(Me.Label50)
        Me.GroupBox9.Location = New System.Drawing.Point(3, 60)
        Me.GroupBox9.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox9.Size = New System.Drawing.Size(1587, 385)
        Me.GroupBox9.TabIndex = 55
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Course Details"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(1326, 20)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(125, 25)
        Me.Label11.TabIndex = 54
        Me.Label11.Text = "Course Units"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(895, 17)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 25)
        Me.Label12.TabIndex = 53
        Me.Label12.Text = "scores"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(603, 21)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(139, 25)
        Me.Label13.TabIndex = 52
        Me.Label13.Text = "Course Codes"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(33, 25)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(118, 25)
        Me.Label14.TabIndex = 51
        Me.Label14.Text = "Course Title"
        '
        'DevOp207_txt
        '
        Me.DevOp207_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevOp207_txt.Location = New System.Drawing.Point(839, 327)
        Me.DevOp207_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.DevOp207_txt.Multiline = True
        Me.DevOp207_txt.Name = "DevOp207_txt"
        Me.DevOp207_txt.Size = New System.Drawing.Size(352, 31)
        Me.DevOp207_txt.TabIndex = 50
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(1341, 332)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(84, 25)
        Me.Label19.TabIndex = 11
        Me.Label19.Text = "(4 UNIT)"
        '
        'DBMS201_txt
        '
        Me.DBMS201_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DBMS201_txt.Location = New System.Drawing.Point(839, 52)
        Me.DBMS201_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.DBMS201_txt.Multiline = True
        Me.DBMS201_txt.Name = "DBMS201_txt"
        Me.DBMS201_txt.Size = New System.Drawing.Size(352, 31)
        Me.DBMS201_txt.TabIndex = 45
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label28.Location = New System.Drawing.Point(604, 168)
        Me.Label28.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(85, 28)
        Me.Label28.TabIndex = 41
        Me.Label28.Text = "(AI 204)"
        '
        'AI204_txt
        '
        Me.AI204_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AI204_txt.Location = New System.Drawing.Point(839, 156)
        Me.AI204_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.AI204_txt.Multiline = True
        Me.AI204_txt.Name = "AI204_txt"
        Me.AI204_txt.Size = New System.Drawing.Size(352, 31)
        Me.AI204_txt.TabIndex = 46
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.Location = New System.Drawing.Point(1341, 278)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(84, 25)
        Me.Label21.TabIndex = 10
        Me.Label21.Text = "(4 UNIT)"
        '
        'AA206_txt
        '
        Me.AA206_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AA206_txt.Location = New System.Drawing.Point(839, 270)
        Me.AA206_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.AA206_txt.Multiline = True
        Me.AA206_txt.Name = "AA206_txt"
        Me.AA206_txt.Size = New System.Drawing.Size(352, 31)
        Me.AA206_txt.TabIndex = 49
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.Location = New System.Drawing.Point(34, 338)
        Me.Label45.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(394, 28)
        Me.Label45.TabIndex = 5
        Me.Label45.Text = "Input Score For Software Dev & IT Opration"
        '
        'UIUX202_txt
        '
        Me.UIUX202_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UIUX202_txt.Location = New System.Drawing.Point(839, 103)
        Me.UIUX202_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.UIUX202_txt.Multiline = True
        Me.UIUX202_txt.Name = "UIUX202_txt"
        Me.UIUX202_txt.Size = New System.Drawing.Size(352, 31)
        Me.UIUX202_txt.TabIndex = 47
        '
        'SQT205_txt
        '
        Me.SQT205_txt.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SQT205_txt.Location = New System.Drawing.Point(839, 210)
        Me.SQT205_txt.Margin = New System.Windows.Forms.Padding(4)
        Me.SQT205_txt.Multiline = True
        Me.SQT205_txt.Name = "SQT205_txt"
        Me.SQT205_txt.Size = New System.Drawing.Size(352, 31)
        Me.SQT205_txt.TabIndex = 48
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(1341, 217)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(84, 25)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = "(3 UNIT)"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label29.Location = New System.Drawing.Point(604, 114)
        Me.Label29.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(119, 28)
        Me.Label29.TabIndex = 40
        Me.Label29.Text = "(UI/UX 202)"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(1341, 162)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 25)
        Me.Label24.TabIndex = 8
        Me.Label24.Text = "(5 UNIT)"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label30.Location = New System.Drawing.Point(604, 65)
        Me.Label30.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(117, 28)
        Me.Label30.TabIndex = 39
        Me.Label30.Text = "(DBMS 201)"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.Location = New System.Drawing.Point(1341, 109)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(84, 25)
        Me.Label25.TabIndex = 7
        Me.Label25.Text = "(3 UNIT)"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.Location = New System.Drawing.Point(34, 114)
        Me.Label46.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(287, 28)
        Me.Label46.TabIndex = 4
        Me.Label46.Text = "Input Score For UI/UX Design "
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Segoe UI Semibold", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.Location = New System.Drawing.Point(1341, 58)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(84, 25)
        Me.Label26.TabIndex = 6
        Me.Label26.Text = "(5 UNIT)"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label27.Location = New System.Drawing.Point(604, 222)
        Me.Label27.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(101, 28)
        Me.Label27.TabIndex = 42
        Me.Label27.Text = "(SQT 205)"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.Location = New System.Drawing.Point(34, 167)
        Me.Label47.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(331, 28)
        Me.Label47.TabIndex = 3
        Me.Label47.Text = "Input Score For Artificial Intelligent"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold)
        Me.Label31.Location = New System.Drawing.Point(604, 283)
        Me.Label31.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(91, 28)
        Me.Label31.TabIndex = 43
        Me.Label31.Text = "(AA 206)"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.Location = New System.Drawing.Point(34, 223)
        Me.Label48.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(372, 28)
        Me.Label48.TabIndex = 2
        Me.Label48.Text = "Input Score For Sofware Quality Testing"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.Location = New System.Drawing.Point(604, 340)
        Me.Label32.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(135, 28)
        Me.Label32.TabIndex = 44
        Me.Label32.Text = "(DEV OP 207)"
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.Location = New System.Drawing.Point(34, 281)
        Me.Label49.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(358, 28)
        Me.Label49.TabIndex = 1
        Me.Label49.Text = "Input Score For Argumented Analysis "
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Segoe UI Semibold", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.Location = New System.Drawing.Point(34, 63)
        Me.Label50.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(446, 28)
        Me.Label50.TabIndex = 0
        Me.Label50.Text = "Input Score For Database Management System "
        '
        'Guna2Panel2
        '
        Me.Guna2Panel2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel2.BackColor = System.Drawing.Color.White
        Me.Guna2Panel2.Controls.Add(Me.Guna2PictureBox4)
        Me.Guna2Panel2.Controls.Add(Me.Guna2GroupBox2)
        Me.Guna2Panel2.Controls.Add(Me.Guna2GroupBox12)
        Me.Guna2Panel2.Location = New System.Drawing.Point(0, 293)
        Me.Guna2Panel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2Panel2.Name = "Guna2Panel2"
        Me.Guna2Panel2.ShadowDecoration.Parent = Me.Guna2Panel2
        Me.Guna2Panel2.Size = New System.Drawing.Size(1960, 799)
        Me.Guna2Panel2.TabIndex = 11
        '
        'Guna2PictureBox4
        '
        Me.Guna2PictureBox4.Image = CType(resources.GetObject("Guna2PictureBox4.Image"), System.Drawing.Image)
        Me.Guna2PictureBox4.Location = New System.Drawing.Point(0, 0)
        Me.Guna2PictureBox4.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2PictureBox4.Name = "Guna2PictureBox4"
        Me.Guna2PictureBox4.ShadowDecoration.Parent = Me.Guna2PictureBox4
        Me.Guna2PictureBox4.Size = New System.Drawing.Size(953, 754)
        Me.Guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox4.TabIndex = 13
        Me.Guna2PictureBox4.TabStop = False
        '
        'Guna2GroupBox2
        '
        Me.Guna2GroupBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2GroupBox2.Controls.Add(Me.TextBox3)
        Me.Guna2GroupBox2.Controls.Add(Me.TextBox2)
        Me.Guna2GroupBox2.Controls.Add(Me.btnClear)
        Me.Guna2GroupBox2.Controls.Add(Me.cmbUnit)
        Me.Guna2GroupBox2.Controls.Add(Me.btnUnitConverter)
        Me.Guna2GroupBox2.Controls.Add(Me.input_con)
        Me.Guna2GroupBox2.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox2.CustomBorderThickness = New System.Windows.Forms.Padding(0)
        Me.Guna2GroupBox2.Font = New System.Drawing.Font("Segoe UI", 17.0!)
        Me.Guna2GroupBox2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Guna2GroupBox2.Location = New System.Drawing.Point(1171, 119)
        Me.Guna2GroupBox2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GroupBox2.Name = "Guna2GroupBox2"
        Me.Guna2GroupBox2.ShadowDecoration.Parent = Me.Guna2GroupBox2
        Me.Guna2GroupBox2.Size = New System.Drawing.Size(640, 550)
        Me.Guna2GroupBox2.TabIndex = 21
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Transparent
        Me.TextBox3.Location = New System.Drawing.Point(181, 385)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(3, 2)
        Me.TextBox3.TabIndex = 21
        Me.TextBox3.Text = Nothing
        '
        'TextBox2
        '
        Me.TextBox2.BorderRadius = 3
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox2.DefaultText = ""
        Me.TextBox2.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.TextBox2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.TextBox2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TextBox2.DisabledState.Parent = Me.TextBox2
        Me.TextBox2.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.TextBox2.Enabled = False
        Me.TextBox2.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox2.FocusedState.Parent = Me.TextBox2
        Me.TextBox2.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox2.HoverState.Parent = Me.TextBox2
        Me.TextBox2.Location = New System.Drawing.Point(221, 853)
        Me.TextBox2.Margin = New System.Windows.Forms.Padding(15, 24, 15, 24)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.TextBox2.PlaceholderText = ""
        Me.TextBox2.SelectedText = ""
        Me.TextBox2.ShadowDecoration.Parent = Me.TextBox2
        Me.TextBox2.Size = New System.Drawing.Size(780, 356)
        Me.TextBox2.TabIndex = 20
        '
        'btnClear
        '
        Me.btnClear.BorderRadius = 4
        Me.btnClear.CheckedState.Parent = Me.btnClear
        Me.btnClear.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnClear.CustomImages.Parent = Me.btnClear
        Me.btnClear.FillColor = System.Drawing.Color.Red
        Me.btnClear.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.ForeColor = System.Drawing.Color.White
        Me.btnClear.HoverState.Parent = Me.btnClear
        Me.btnClear.Location = New System.Drawing.Point(409, 267)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.ShadowDecoration.Parent = Me.btnClear
        Me.btnClear.Size = New System.Drawing.Size(125, 62)
        Me.btnClear.TabIndex = 19
        Me.btnClear.Text = "CLEAR"
        '
        'cmbUnit
        '
        Me.cmbUnit.BackColor = System.Drawing.Color.Transparent
        Me.cmbUnit.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.cmbUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbUnit.FocusedColor = System.Drawing.Color.Empty
        Me.cmbUnit.FocusedState.Parent = Me.cmbUnit
        Me.cmbUnit.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.cmbUnit.ForeColor = System.Drawing.Color.FromArgb(CType(CType(68, Byte), Integer), CType(CType(88, Byte), Integer), CType(CType(112, Byte), Integer))
        Me.cmbUnit.FormattingEnabled = True
        Me.cmbUnit.HoverState.Parent = Me.cmbUnit
        Me.cmbUnit.ItemHeight = 30
        Me.cmbUnit.ItemsAppearance.Parent = Me.cmbUnit
        Me.cmbUnit.Location = New System.Drawing.Point(118, 77)
        Me.cmbUnit.Margin = New System.Windows.Forms.Padding(4)
        Me.cmbUnit.Name = "cmbUnit"
        Me.cmbUnit.ShadowDecoration.Parent = Me.cmbUnit
        Me.cmbUnit.Size = New System.Drawing.Size(416, 36)
        Me.cmbUnit.TabIndex = 14
        '
        'btnUnitConverter
        '
        Me.btnUnitConverter.BorderRadius = 4
        Me.btnUnitConverter.CheckedState.Parent = Me.btnUnitConverter
        Me.btnUnitConverter.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnUnitConverter.CustomImages.Parent = Me.btnUnitConverter
        Me.btnUnitConverter.FillColor = System.Drawing.SystemColors.HotTrack
        Me.btnUnitConverter.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUnitConverter.ForeColor = System.Drawing.Color.White
        Me.btnUnitConverter.HoverState.Parent = Me.btnUnitConverter
        Me.btnUnitConverter.Location = New System.Drawing.Point(118, 266)
        Me.btnUnitConverter.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnUnitConverter.Name = "btnUnitConverter"
        Me.btnUnitConverter.ShadowDecoration.Parent = Me.btnUnitConverter
        Me.btnUnitConverter.Size = New System.Drawing.Size(164, 62)
        Me.btnUnitConverter.TabIndex = 18
        Me.btnUnitConverter.Text = "CONVERT"
        '
        'input_con
        '
        Me.input_con.BorderColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.input_con.BorderRadius = 3
        Me.input_con.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.input_con.DefaultText = ""
        Me.input_con.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.input_con.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.input_con.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.input_con.DisabledState.Parent = Me.input_con
        Me.input_con.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.input_con.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.input_con.FocusedState.Parent = Me.input_con
        Me.input_con.Font = New System.Drawing.Font("Segoe UI", 13.0!)
        Me.input_con.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.input_con.HoverState.Parent = Me.input_con
        Me.input_con.Location = New System.Drawing.Point(118, 147)
        Me.input_con.Margin = New System.Windows.Forms.Padding(9, 12, 9, 12)
        Me.input_con.Name = "input_con"
        Me.input_con.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.input_con.PlaceholderText = ""
        Me.input_con.SelectedText = ""
        Me.input_con.ShadowDecoration.Parent = Me.input_con
        Me.input_con.Size = New System.Drawing.Size(416, 90)
        Me.input_con.TabIndex = 15
        '
        'Guna2GroupBox12
        '
        Me.Guna2GroupBox12.BorderColor = System.Drawing.Color.FromArgb(CType(CType(217, Byte), Integer), CType(CType(221, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Guna2GroupBox12.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox12.Font = New System.Drawing.Font("Lucida Sans Unicode", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox12.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox12.Location = New System.Drawing.Point(1132, 54)
        Me.Guna2GroupBox12.Name = "Guna2GroupBox12"
        Me.Guna2GroupBox12.ShadowDecoration.Parent = Me.Guna2GroupBox12
        Me.Guna2GroupBox12.Size = New System.Drawing.Size(717, 646)
        Me.Guna2GroupBox12.TabIndex = 22
        Me.Guna2GroupBox12.Text = "UNIT CONVERTER. "
        '
        'txtDisplay
        '
        Me.txtDisplay.BackColor = System.Drawing.Color.White
        Me.txtDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtDisplay.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDisplay.Location = New System.Drawing.Point(1068, 194)
        Me.txtDisplay.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(371, 69)
        Me.txtDisplay.TabIndex = 65
        Me.txtDisplay.Text = "0"
        Me.txtDisplay.TextAlign = System.Drawing.ContentAlignment.BottomRight
        '
        'btnBackspace
        '
        Me.btnBackspace.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackspace.Location = New System.Drawing.Point(1066, 273)
        Me.btnBackspace.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBackspace.Name = "btnBackspace"
        Me.btnBackspace.Size = New System.Drawing.Size(95, 65)
        Me.btnBackspace.TabIndex = 72
        Me.btnBackspace.Text = "Backspace"
        Me.btnBackspace.UseVisualStyleBackColor = True
        '
        'btnDel
        '
        Me.btnDel.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDel.Location = New System.Drawing.Point(1160, 273)
        Me.btnDel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDel.Name = "btnDel"
        Me.btnDel.Size = New System.Drawing.Size(95, 65)
        Me.btnDel.TabIndex = 78
        Me.btnDel.Text = "CE"
        Me.btnDel.UseVisualStyleBackColor = True
        '
        'btnNo7
        '
        Me.btnNo7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNo7.Location = New System.Drawing.Point(1066, 341)
        Me.btnNo7.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNo7.Name = "btnNo7"
        Me.btnNo7.Size = New System.Drawing.Size(95, 65)
        Me.btnNo7.TabIndex = 76
        Me.btnNo7.Text = "7"
        Me.btnNo7.UseVisualStyleBackColor = True
        '
        'btnClr
        '
        Me.btnClr.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClr.Location = New System.Drawing.Point(1255, 273)
        Me.btnClr.Margin = New System.Windows.Forms.Padding(4)
        Me.btnClr.Name = "btnClr"
        Me.btnClr.Size = New System.Drawing.Size(95, 65)
        Me.btnClr.TabIndex = 80
        Me.btnClr.Text = "C"
        Me.btnClr.UseVisualStyleBackColor = True
        '
        'btnNegate
        '
        Me.btnNegate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNegate.Location = New System.Drawing.Point(1349, 273)
        Me.btnNegate.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNegate.Name = "btnNegate"
        Me.btnNegate.Size = New System.Drawing.Size(95, 65)
        Me.btnNegate.TabIndex = 84
        Me.btnNegate.Text = "±"
        Me.btnNegate.UseVisualStyleBackColor = True
        '
        'btnNo4
        '
        Me.btnNo4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNo4.Location = New System.Drawing.Point(1066, 407)
        Me.btnNo4.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNo4.Name = "btnNo4"
        Me.btnNo4.Size = New System.Drawing.Size(95, 65)
        Me.btnNo4.TabIndex = 82
        Me.btnNo4.Text = "4"
        Me.btnNo4.UseVisualStyleBackColor = True
        '
        'btnNo8
        '
        Me.btnNo8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNo8.Location = New System.Drawing.Point(1160, 341)
        Me.btnNo8.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNo8.Name = "btnNo8"
        Me.btnNo8.Size = New System.Drawing.Size(95, 65)
        Me.btnNo8.TabIndex = 68
        Me.btnNo8.Text = "8"
        Me.btnNo8.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(1066, 476)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(95, 65)
        Me.Button3.TabIndex = 66
        Me.Button3.Text = "1"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Location = New System.Drawing.Point(1066, 543)
        Me.Button13.Margin = New System.Windows.Forms.Padding(4)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(95, 65)
        Me.Button13.TabIndex = 70
        Me.Button13.Text = "0"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'btnNo9
        '
        Me.btnNo9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNo9.Location = New System.Drawing.Point(1255, 341)
        Me.btnNo9.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNo9.Name = "btnNo9"
        Me.btnNo9.Size = New System.Drawing.Size(95, 65)
        Me.btnNo9.TabIndex = 74
        Me.btnNo9.Text = "9"
        Me.btnNo9.UseVisualStyleBackColor = True
        '
        'btnNoplus
        '
        Me.btnNoplus.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNoplus.Location = New System.Drawing.Point(1349, 341)
        Me.btnNoplus.Margin = New System.Windows.Forms.Padding(4)
        Me.btnNoplus.Name = "btnNoplus"
        Me.btnNoplus.Size = New System.Drawing.Size(95, 65)
        Me.btnNoplus.TabIndex = 92
        Me.btnNoplus.Text = "+"
        Me.btnNoplus.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(1160, 407)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(95, 65)
        Me.Button8.TabIndex = 99
        Me.Button8.Text = "5"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(1255, 407)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(95, 65)
        Me.Button2.TabIndex = 98
        Me.Button2.Text = "6"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button18
        '
        Me.Button18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.Location = New System.Drawing.Point(1349, 407)
        Me.Button18.Margin = New System.Windows.Forms.Padding(4)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(95, 65)
        Me.Button18.TabIndex = 97
        Me.Button18.Text = "-"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(1160, 476)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(95, 65)
        Me.Button11.TabIndex = 105
        Me.Button11.Text = "2"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'btnDot
        '
        Me.btnDot.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDot.Location = New System.Drawing.Point(1160, 543)
        Me.btnDot.Margin = New System.Windows.Forms.Padding(4)
        Me.btnDot.Name = "btnDot"
        Me.btnDot.Size = New System.Drawing.Size(95, 65)
        Me.btnDot.TabIndex = 101
        Me.btnDot.Text = "."
        Me.btnDot.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Location = New System.Drawing.Point(1255, 476)
        Me.Button12.Margin = New System.Windows.Forms.Padding(4)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(95, 65)
        Me.Button12.TabIndex = 89
        Me.Button12.Text = "3"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.Location = New System.Drawing.Point(1349, 476)
        Me.Button19.Margin = New System.Windows.Forms.Padding(4)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(95, 65)
        Me.Button19.TabIndex = 88
        Me.Button19.Text = "*"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'btnEquals
        '
        Me.btnEquals.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEquals.Location = New System.Drawing.Point(1255, 543)
        Me.btnEquals.Margin = New System.Windows.Forms.Padding(4)
        Me.btnEquals.Name = "btnEquals"
        Me.btnEquals.Size = New System.Drawing.Size(95, 65)
        Me.btnEquals.TabIndex = 94
        Me.btnEquals.Text = "="
        Me.btnEquals.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.Location = New System.Drawing.Point(1349, 543)
        Me.Button20.Margin = New System.Windows.Forms.Padding(4)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(95, 65)
        Me.Button20.TabIndex = 93
        Me.Button20.Text = "/"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'txtShow
        '
        Me.txtShow.BackColor = System.Drawing.Color.White
        Me.txtShow.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtShow.Enabled = False
        Me.txtShow.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtShow.Location = New System.Drawing.Point(1113, 197)
        Me.txtShow.Margin = New System.Windows.Forms.Padding(4)
        Me.txtShow.Name = "txtShow"
        Me.txtShow.Size = New System.Drawing.Size(67, 16)
        Me.txtShow.TabIndex = 107
        '
        'Guna2PictureBox3
        '
        Me.Guna2PictureBox3.FillColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2PictureBox3.Image = CType(resources.GetObject("Guna2PictureBox3.Image"), System.Drawing.Image)
        Me.Guna2PictureBox3.Location = New System.Drawing.Point(16, 32)
        Me.Guna2PictureBox3.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2PictureBox3.Name = "Guna2PictureBox3"
        Me.Guna2PictureBox3.ShadowDecoration.Parent = Me.Guna2PictureBox3
        Me.Guna2PictureBox3.Size = New System.Drawing.Size(839, 716)
        Me.Guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox3.TabIndex = 109
        Me.Guna2PictureBox3.TabStop = False
        '
        'simple_calc_panel
        '
        Me.simple_calc_panel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.simple_calc_panel.BorderRadius = 4
        Me.simple_calc_panel.Controls.Add(Me.Guna2PictureBox3)
        Me.simple_calc_panel.Controls.Add(Me.txtShow)
        Me.simple_calc_panel.Controls.Add(Me.Button20)
        Me.simple_calc_panel.Controls.Add(Me.btnEquals)
        Me.simple_calc_panel.Controls.Add(Me.Button19)
        Me.simple_calc_panel.Controls.Add(Me.Button12)
        Me.simple_calc_panel.Controls.Add(Me.btnDot)
        Me.simple_calc_panel.Controls.Add(Me.Button11)
        Me.simple_calc_panel.Controls.Add(Me.Button18)
        Me.simple_calc_panel.Controls.Add(Me.Button2)
        Me.simple_calc_panel.Controls.Add(Me.Button8)
        Me.simple_calc_panel.Controls.Add(Me.btnNoplus)
        Me.simple_calc_panel.Controls.Add(Me.btnNo9)
        Me.simple_calc_panel.Controls.Add(Me.Button13)
        Me.simple_calc_panel.Controls.Add(Me.Button3)
        Me.simple_calc_panel.Controls.Add(Me.btnNo8)
        Me.simple_calc_panel.Controls.Add(Me.btnNo4)
        Me.simple_calc_panel.Controls.Add(Me.btnNegate)
        Me.simple_calc_panel.Controls.Add(Me.btnClr)
        Me.simple_calc_panel.Controls.Add(Me.btnNo7)
        Me.simple_calc_panel.Controls.Add(Me.btnDel)
        Me.simple_calc_panel.Controls.Add(Me.btnBackspace)
        Me.simple_calc_panel.Controls.Add(Me.txtDisplay)
        Me.simple_calc_panel.Controls.Add(Me.GroupBox8)
        Me.simple_calc_panel.Controls.Add(Me.Guna2GroupBox1)
        Me.simple_calc_panel.Location = New System.Drawing.Point(0, 322)
        Me.simple_calc_panel.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.simple_calc_panel.Name = "simple_calc_panel"
        Me.simple_calc_panel.ShadowDecoration.Parent = Me.simple_calc_panel
        Me.simple_calc_panel.Size = New System.Drawing.Size(1912, 767)
        Me.simple_calc_panel.TabIndex = 6
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.GroupBox8.Controls.Add(Me.btnPercent)
        Me.GroupBox8.Controls.Add(Me.btnOct)
        Me.GroupBox8.Controls.Add(Me.Button38)
        Me.GroupBox8.Controls.Add(Me.btnHex)
        Me.GroupBox8.Controls.Add(Me.btnMod)
        Me.GroupBox8.Controls.Add(Me.btnTan)
        Me.GroupBox8.Controls.Add(Me.Button34)
        Me.GroupBox8.Controls.Add(Me.btnBin)
        Me.GroupBox8.Controls.Add(Me.btnCos)
        Me.GroupBox8.Controls.Add(Me.Button31)
        Me.GroupBox8.Controls.Add(Me.Button30)
        Me.GroupBox8.Controls.Add(Me.btnExp)
        Me.GroupBox8.Controls.Add(Me.btnTanh)
        Me.GroupBox8.Controls.Add(Me.btnSin)
        Me.GroupBox8.Controls.Add(Me.btnCosh)
        Me.GroupBox8.Controls.Add(Me.Button25)
        Me.GroupBox8.Controls.Add(Me.BtnSqrt)
        Me.GroupBox8.Controls.Add(Me.btnSignh)
        Me.GroupBox8.Controls.Add(Me.btnLog)
        Me.GroupBox8.Controls.Add(Me.btnPi)
        Me.GroupBox8.Location = New System.Drawing.Point(1059, 179)
        Me.GroupBox8.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox8.Size = New System.Drawing.Size(771, 443)
        Me.GroupBox8.TabIndex = 106
        Me.GroupBox8.TabStop = False
        '
        'btnPercent
        '
        Me.btnPercent.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPercent.Location = New System.Drawing.Point(666, 364)
        Me.btnPercent.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPercent.Name = "btnPercent"
        Me.btnPercent.Size = New System.Drawing.Size(95, 65)
        Me.btnPercent.TabIndex = 158
        Me.btnPercent.Text = "%"
        Me.btnPercent.UseVisualStyleBackColor = True
        '
        'btnOct
        '
        Me.btnOct.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOct.Location = New System.Drawing.Point(572, 364)
        Me.btnOct.Margin = New System.Windows.Forms.Padding(4)
        Me.btnOct.Name = "btnOct"
        Me.btnOct.Size = New System.Drawing.Size(95, 65)
        Me.btnOct.TabIndex = 159
        Me.btnOct.Text = "Oct"
        Me.btnOct.UseVisualStyleBackColor = True
        '
        'Button38
        '
        Me.Button38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.Location = New System.Drawing.Point(666, 298)
        Me.Button38.Margin = New System.Windows.Forms.Padding(4)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(95, 65)
        Me.Button38.TabIndex = 156
        Me.Button38.Text = "In x"
        Me.Button38.UseVisualStyleBackColor = True
        '
        'btnHex
        '
        Me.btnHex.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHex.Location = New System.Drawing.Point(572, 298)
        Me.btnHex.Margin = New System.Windows.Forms.Padding(4)
        Me.btnHex.Name = "btnHex"
        Me.btnHex.Size = New System.Drawing.Size(95, 65)
        Me.btnHex.TabIndex = 155
        Me.btnHex.Text = "Hex"
        Me.btnHex.UseVisualStyleBackColor = True
        '
        'btnMod
        '
        Me.btnMod.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMod.Location = New System.Drawing.Point(478, 364)
        Me.btnMod.Margin = New System.Windows.Forms.Padding(4)
        Me.btnMod.Name = "btnMod"
        Me.btnMod.Size = New System.Drawing.Size(95, 65)
        Me.btnMod.TabIndex = 157
        Me.btnMod.Text = "Mod"
        Me.btnMod.UseVisualStyleBackColor = True
        '
        'btnTan
        '
        Me.btnTan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTan.Location = New System.Drawing.Point(478, 298)
        Me.btnTan.Margin = New System.Windows.Forms.Padding(4)
        Me.btnTan.Name = "btnTan"
        Me.btnTan.Size = New System.Drawing.Size(95, 65)
        Me.btnTan.TabIndex = 162
        Me.btnTan.Text = "Tan"
        Me.btnTan.UseVisualStyleBackColor = True
        '
        'Button34
        '
        Me.Button34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.Location = New System.Drawing.Point(666, 229)
        Me.Button34.Margin = New System.Windows.Forms.Padding(4)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(95, 65)
        Me.Button34.TabIndex = 163
        Me.Button34.Text = "1/x"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'btnBin
        '
        Me.btnBin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBin.Location = New System.Drawing.Point(572, 229)
        Me.btnBin.Margin = New System.Windows.Forms.Padding(4)
        Me.btnBin.Name = "btnBin"
        Me.btnBin.Size = New System.Drawing.Size(95, 65)
        Me.btnBin.TabIndex = 164
        Me.btnBin.Text = "Bin"
        Me.btnBin.UseVisualStyleBackColor = True
        '
        'btnCos
        '
        Me.btnCos.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCos.Location = New System.Drawing.Point(478, 229)
        Me.btnCos.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCos.Name = "btnCos"
        Me.btnCos.Size = New System.Drawing.Size(95, 65)
        Me.btnCos.TabIndex = 160
        Me.btnCos.Text = "Cos"
        Me.btnCos.UseVisualStyleBackColor = True
        '
        'Button31
        '
        Me.Button31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.Location = New System.Drawing.Point(666, 163)
        Me.Button31.Margin = New System.Windows.Forms.Padding(4)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(95, 65)
        Me.Button31.TabIndex = 161
        Me.Button31.Text = "x^3"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Button30
        '
        Me.Button30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.Location = New System.Drawing.Point(572, 163)
        Me.Button30.Margin = New System.Windows.Forms.Padding(4)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(95, 65)
        Me.Button30.TabIndex = 154
        Me.Button30.Text = "Dec"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'btnExp
        '
        Me.btnExp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExp.Location = New System.Drawing.Point(384, 364)
        Me.btnExp.Margin = New System.Windows.Forms.Padding(4)
        Me.btnExp.Name = "btnExp"
        Me.btnExp.Size = New System.Drawing.Size(95, 65)
        Me.btnExp.TabIndex = 147
        Me.btnExp.Text = "Exp"
        Me.btnExp.UseVisualStyleBackColor = True
        '
        'btnTanh
        '
        Me.btnTanh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTanh.Location = New System.Drawing.Point(384, 297)
        Me.btnTanh.Margin = New System.Windows.Forms.Padding(4)
        Me.btnTanh.Name = "btnTanh"
        Me.btnTanh.Size = New System.Drawing.Size(95, 65)
        Me.btnTanh.TabIndex = 148
        Me.btnTanh.Text = "Tanh"
        Me.btnTanh.UseVisualStyleBackColor = True
        '
        'btnSin
        '
        Me.btnSin.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSin.Location = New System.Drawing.Point(478, 163)
        Me.btnSin.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSin.Name = "btnSin"
        Me.btnSin.Size = New System.Drawing.Size(95, 65)
        Me.btnSin.TabIndex = 145
        Me.btnSin.Text = "Sin"
        Me.btnSin.UseVisualStyleBackColor = True
        '
        'btnCosh
        '
        Me.btnCosh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCosh.Location = New System.Drawing.Point(384, 228)
        Me.btnCosh.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCosh.Name = "btnCosh"
        Me.btnCosh.Size = New System.Drawing.Size(95, 65)
        Me.btnCosh.TabIndex = 146
        Me.btnCosh.Text = "Cosh"
        Me.btnCosh.UseVisualStyleBackColor = True
        '
        'Button25
        '
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.Location = New System.Drawing.Point(666, 95)
        Me.Button25.Margin = New System.Windows.Forms.Padding(4)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(95, 65)
        Me.Button25.TabIndex = 149
        Me.Button25.Text = "x²"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'BtnSqrt
        '
        Me.BtnSqrt.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnSqrt.Location = New System.Drawing.Point(572, 95)
        Me.BtnSqrt.Margin = New System.Windows.Forms.Padding(4)
        Me.BtnSqrt.Name = "BtnSqrt"
        Me.BtnSqrt.Size = New System.Drawing.Size(95, 65)
        Me.BtnSqrt.TabIndex = 152
        Me.BtnSqrt.Text = "Sqrt"
        Me.BtnSqrt.UseVisualStyleBackColor = True
        '
        'btnSignh
        '
        Me.btnSignh.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSignh.Location = New System.Drawing.Point(384, 162)
        Me.btnSignh.Margin = New System.Windows.Forms.Padding(4)
        Me.btnSignh.Name = "btnSignh"
        Me.btnSignh.Size = New System.Drawing.Size(95, 65)
        Me.btnSignh.TabIndex = 153
        Me.btnSignh.Text = "Sinh"
        Me.btnSignh.UseVisualStyleBackColor = True
        '
        'btnLog
        '
        Me.btnLog.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLog.Location = New System.Drawing.Point(478, 95)
        Me.btnLog.Margin = New System.Windows.Forms.Padding(4)
        Me.btnLog.Name = "btnLog"
        Me.btnLog.Size = New System.Drawing.Size(95, 65)
        Me.btnLog.TabIndex = 150
        Me.btnLog.Text = "Log"
        Me.btnLog.UseVisualStyleBackColor = True
        '
        'btnPi
        '
        Me.btnPi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPi.Location = New System.Drawing.Point(384, 95)
        Me.btnPi.Margin = New System.Windows.Forms.Padding(4)
        Me.btnPi.Name = "btnPi"
        Me.btnPi.Size = New System.Drawing.Size(95, 65)
        Me.btnPi.TabIndex = 151
        Me.btnPi.Text = "π"
        Me.btnPi.UseVisualStyleBackColor = True
        '
        'Guna2GroupBox1
        '
        Me.Guna2GroupBox1.CustomBorderColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2GroupBox1.Font = New System.Drawing.Font("Segoe UI", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.Guna2GroupBox1.Location = New System.Drawing.Point(1037, 125)
        Me.Guna2GroupBox1.Name = "Guna2GroupBox1"
        Me.Guna2GroupBox1.ShadowDecoration.Parent = Me.Guna2GroupBox1
        Me.Guna2GroupBox1.Size = New System.Drawing.Size(812, 508)
        Me.Guna2GroupBox1.TabIndex = 110
        Me.Guna2GroupBox1.Text = "SCIENTIFIC CALCULATOR"
        '
        'close_button
        '
        Me.close_button.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.close_button.CheckedState.Parent = Me.close_button
        Me.close_button.Cursor = System.Windows.Forms.Cursors.Hand
        Me.close_button.CustomImages.Parent = Me.close_button
        Me.close_button.FillColor = System.Drawing.Color.Red
        Me.close_button.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.close_button.ForeColor = System.Drawing.Color.White
        Me.close_button.HoverState.Parent = Me.close_button
        Me.close_button.Location = New System.Drawing.Point(1858, 1)
        Me.close_button.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.close_button.Name = "close_button"
        Me.close_button.ShadowDecoration.Parent = Me.close_button
        Me.close_button.Size = New System.Drawing.Size(53, 42)
        Me.close_button.TabIndex = 0
        Me.close_button.Text = "X"
        '
        'mini_btn
        '
        Me.mini_btn.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.mini_btn.CheckedState.Parent = Me.mini_btn
        Me.mini_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.mini_btn.CustomImages.Parent = Me.mini_btn
        Me.mini_btn.FillColor = System.Drawing.Color.DarkGray
        Me.mini_btn.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.mini_btn.ForeColor = System.Drawing.Color.White
        Me.mini_btn.HoverState.Parent = Me.mini_btn
        Me.mini_btn.Location = New System.Drawing.Point(1808, 1)
        Me.mini_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.mini_btn.Name = "mini_btn"
        Me.mini_btn.PressedColor = System.Drawing.Color.DarkGray
        Me.mini_btn.ShadowDecoration.Parent = Me.mini_btn
        Me.mini_btn.Size = New System.Drawing.Size(51, 42)
        Me.mini_btn.TabIndex = 1
        Me.mini_btn.Text = "-"
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = CType(resources.GetObject("Guna2PictureBox1.Image"), System.Drawing.Image)
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(1, 1)
        Me.Guna2PictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.ShadowDecoration.Parent = Me.Guna2PictureBox1
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(59, 44)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2PictureBox1.TabIndex = 4
        Me.Guna2PictureBox1.TabStop = False
        '
        'Guna2Panel1
        '
        Me.Guna2Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2Panel1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Guna2Panel1.Controls.Add(Me.Guna2HtmlLabel11)
        Me.Guna2Panel1.Controls.Add(Me.Guna2PictureBox1)
        Me.Guna2Panel1.Controls.Add(Me.mini_btn)
        Me.Guna2Panel1.Controls.Add(Me.close_button)
        Me.Guna2Panel1.Location = New System.Drawing.Point(0, -1)
        Me.Guna2Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2Panel1.Name = "Guna2Panel1"
        Me.Guna2Panel1.ShadowDecoration.Parent = Me.Guna2Panel1
        Me.Guna2Panel1.Size = New System.Drawing.Size(1926, 45)
        Me.Guna2Panel1.TabIndex = 0
        '
        'Guna2HtmlLabel11
        '
        Me.Guna2HtmlLabel11.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel11.AutoSize = False
        Me.Guna2HtmlLabel11.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel11.Font = New System.Drawing.Font("Arial", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel11.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Guna2HtmlLabel11.Location = New System.Drawing.Point(93, 0)
        Me.Guna2HtmlLabel11.Name = "Guna2HtmlLabel11"
        Me.Guna2HtmlLabel11.Size = New System.Drawing.Size(357, 45)
        Me.Guna2HtmlLabel11.TabIndex = 12
        Me.Guna2HtmlLabel11.Text = "AfooTECH GLOBAL I.T SOLUTION"
        Me.Guna2HtmlLabel11.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.Guna2HtmlLabel11.UseGdiPlusTextRendering = True
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.AutoSize = False
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Lucida Sans Unicode", 13.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(73, 6)
        Me.Guna2HtmlLabel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(920, 38)
        Me.Guna2HtmlLabel1.TabIndex = 3
        Me.Guna2HtmlLabel1.Text = "AFOOTECH MULTI-FUNTION  CALCULATOR"
        Me.Guna2HtmlLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Guna2CustomGradientPanel1
        '
        Me.Guna2CustomGradientPanel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2CustomGradientPanel1.BorderRadius = 4
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2CustomGradientPanel2)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2CirclePictureBox1)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel10)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel9)
        Me.Guna2CustomGradientPanel1.Location = New System.Drawing.Point(0, 44)
        Me.Guna2CustomGradientPanel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2CustomGradientPanel1.Name = "Guna2CustomGradientPanel1"
        Me.Guna2CustomGradientPanel1.ShadowDecoration.Parent = Me.Guna2CustomGradientPanel1
        Me.Guna2CustomGradientPanel1.Size = New System.Drawing.Size(1926, 249)
        Me.Guna2CustomGradientPanel1.TabIndex = 4
        '
        'Guna2CustomGradientPanel2
        '
        Me.Guna2CustomGradientPanel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2CustomGradientPanel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2CustomGradientPanel2.BorderRadius = 3
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.home_btn)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.GpCalcu_btn)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.simple_calc_btn)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.Unit_converterBtn)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.Guna2Button4)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.AgeCalc_btn)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.LoanApp_btn)
        Me.Guna2CustomGradientPanel2.Controls.Add(Me.BOYLES_LAW_Btn)
        Me.Guna2CustomGradientPanel2.FillColor = System.Drawing.SystemColors.ControlLight
        Me.Guna2CustomGradientPanel2.FillColor2 = System.Drawing.SystemColors.ControlLight
        Me.Guna2CustomGradientPanel2.FillColor3 = System.Drawing.SystemColors.ControlLight
        Me.Guna2CustomGradientPanel2.FillColor4 = System.Drawing.SystemColors.ControlLight
        Me.Guna2CustomGradientPanel2.Location = New System.Drawing.Point(303, 151)
        Me.Guna2CustomGradientPanel2.Name = "Guna2CustomGradientPanel2"
        Me.Guna2CustomGradientPanel2.ShadowDecoration.Parent = Me.Guna2CustomGradientPanel2
        Me.Guna2CustomGradientPanel2.Size = New System.Drawing.Size(1566, 77)
        Me.Guna2CustomGradientPanel2.TabIndex = 17
        '
        'home_btn
        '
        Me.home_btn.BorderRadius = 4
        Me.home_btn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.home_btn.CheckedState.Parent = Me.home_btn
        Me.home_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.home_btn.CustomImages.Parent = Me.home_btn
        Me.home_btn.FillColor = System.Drawing.Color.DarkGray
        Me.home_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.home_btn.ForeColor = System.Drawing.Color.White
        Me.home_btn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.home_btn.HoverState.Parent = Me.home_btn
        Me.home_btn.Location = New System.Drawing.Point(25, 17)
        Me.home_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.home_btn.Name = "home_btn"
        Me.home_btn.ShadowDecoration.Parent = Me.home_btn
        Me.home_btn.Size = New System.Drawing.Size(164, 46)
        Me.home_btn.TabIndex = 21
        Me.home_btn.Text = "HOME"
        '
        'GpCalcu_btn
        '
        Me.GpCalcu_btn.BorderRadius = 4
        Me.GpCalcu_btn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.GpCalcu_btn.CheckedState.Parent = Me.GpCalcu_btn
        Me.GpCalcu_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GpCalcu_btn.CustomImages.Parent = Me.GpCalcu_btn
        Me.GpCalcu_btn.FillColor = System.Drawing.Color.DarkGray
        Me.GpCalcu_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GpCalcu_btn.ForeColor = System.Drawing.Color.White
        Me.GpCalcu_btn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.GpCalcu_btn.HoverState.Parent = Me.GpCalcu_btn
        Me.GpCalcu_btn.Location = New System.Drawing.Point(1194, 17)
        Me.GpCalcu_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GpCalcu_btn.Name = "GpCalcu_btn"
        Me.GpCalcu_btn.ShadowDecoration.Parent = Me.GpCalcu_btn
        Me.GpCalcu_btn.Size = New System.Drawing.Size(222, 46)
        Me.GpCalcu_btn.TabIndex = 19
        Me.GpCalcu_btn.Text = "GP CALCULATOR"
        '
        'simple_calc_btn
        '
        Me.simple_calc_btn.BorderRadius = 4
        Me.simple_calc_btn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.simple_calc_btn.CheckedState.Parent = Me.simple_calc_btn
        Me.simple_calc_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.simple_calc_btn.CustomImages.Parent = Me.simple_calc_btn
        Me.simple_calc_btn.FillColor = System.Drawing.Color.DarkGray
        Me.simple_calc_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.simple_calc_btn.ForeColor = System.Drawing.Color.White
        Me.simple_calc_btn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.simple_calc_btn.HoverState.Parent = Me.simple_calc_btn
        Me.simple_calc_btn.Location = New System.Drawing.Point(212, 17)
        Me.simple_calc_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.simple_calc_btn.Name = "simple_calc_btn"
        Me.simple_calc_btn.ShadowDecoration.Parent = Me.simple_calc_btn
        Me.simple_calc_btn.Size = New System.Drawing.Size(254, 46)
        Me.simple_calc_btn.TabIndex = 15
        Me.simple_calc_btn.Text = "SCIENTIFIC CALCULATOR"
        '
        'Unit_converterBtn
        '
        Me.Unit_converterBtn.BorderRadius = 4
        Me.Unit_converterBtn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.Unit_converterBtn.CheckedState.Parent = Me.Unit_converterBtn
        Me.Unit_converterBtn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Unit_converterBtn.CustomImages.Parent = Me.Unit_converterBtn
        Me.Unit_converterBtn.FillColor = System.Drawing.Color.DarkGray
        Me.Unit_converterBtn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Unit_converterBtn.ForeColor = System.Drawing.Color.White
        Me.Unit_converterBtn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.Unit_converterBtn.HoverState.Parent = Me.Unit_converterBtn
        Me.Unit_converterBtn.Location = New System.Drawing.Point(1438, 17)
        Me.Unit_converterBtn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Unit_converterBtn.Name = "Unit_converterBtn"
        Me.Unit_converterBtn.ShadowDecoration.Parent = Me.Unit_converterBtn
        Me.Unit_converterBtn.Size = New System.Drawing.Size(222, 46)
        Me.Unit_converterBtn.TabIndex = 20
        Me.Unit_converterBtn.Text = "UNIT CONVERTER"
        '
        'Guna2Button4
        '
        Me.Guna2Button4.BorderRadius = 4
        Me.Guna2Button4.CheckedState.Parent = Me.Guna2Button4
        Me.Guna2Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Guna2Button4.CustomImages.Parent = Me.Guna2Button4
        Me.Guna2Button4.FillColor = System.Drawing.SystemColors.HotTrack
        Me.Guna2Button4.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2Button4.ForeColor = System.Drawing.Color.White
        Me.Guna2Button4.HoverState.Parent = Me.Guna2Button4
        Me.Guna2Button4.Location = New System.Drawing.Point(-172, 15)
        Me.Guna2Button4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2Button4.Name = "Guna2Button4"
        Me.Guna2Button4.ShadowDecoration.Parent = Me.Guna2Button4
        Me.Guna2Button4.Size = New System.Drawing.Size(162, 46)
        Me.Guna2Button4.TabIndex = 14
        Me.Guna2Button4.Text = "HOME"
        '
        'AgeCalc_btn
        '
        Me.AgeCalc_btn.BorderRadius = 4
        Me.AgeCalc_btn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.AgeCalc_btn.CheckedState.Parent = Me.AgeCalc_btn
        Me.AgeCalc_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.AgeCalc_btn.CustomImages.Parent = Me.AgeCalc_btn
        Me.AgeCalc_btn.FillColor = System.Drawing.Color.DarkGray
        Me.AgeCalc_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AgeCalc_btn.ForeColor = System.Drawing.Color.White
        Me.AgeCalc_btn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.AgeCalc_btn.HoverState.Parent = Me.AgeCalc_btn
        Me.AgeCalc_btn.Location = New System.Drawing.Point(945, 17)
        Me.AgeCalc_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.AgeCalc_btn.Name = "AgeCalc_btn"
        Me.AgeCalc_btn.ShadowDecoration.Parent = Me.AgeCalc_btn
        Me.AgeCalc_btn.Size = New System.Drawing.Size(222, 46)
        Me.AgeCalc_btn.TabIndex = 18
        Me.AgeCalc_btn.Text = "AGE CALCULATOR "
        '
        'LoanApp_btn
        '
        Me.LoanApp_btn.BorderRadius = 4
        Me.LoanApp_btn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.LoanApp_btn.CheckedState.Parent = Me.LoanApp_btn
        Me.LoanApp_btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LoanApp_btn.CustomImages.Parent = Me.LoanApp_btn
        Me.LoanApp_btn.FillColor = System.Drawing.Color.DarkGray
        Me.LoanApp_btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LoanApp_btn.ForeColor = System.Drawing.Color.White
        Me.LoanApp_btn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.LoanApp_btn.HoverState.Parent = Me.LoanApp_btn
        Me.LoanApp_btn.Location = New System.Drawing.Point(487, 17)
        Me.LoanApp_btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LoanApp_btn.Name = "LoanApp_btn"
        Me.LoanApp_btn.ShadowDecoration.Parent = Me.LoanApp_btn
        Me.LoanApp_btn.Size = New System.Drawing.Size(222, 46)
        Me.LoanApp_btn.TabIndex = 16
        Me.LoanApp_btn.Text = "LOAN APP"
        '
        'BOYLES_LAW_Btn
        '
        Me.BOYLES_LAW_Btn.BorderRadius = 4
        Me.BOYLES_LAW_Btn.CheckedState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.BOYLES_LAW_Btn.CheckedState.Parent = Me.BOYLES_LAW_Btn
        Me.BOYLES_LAW_Btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BOYLES_LAW_Btn.CustomImages.Parent = Me.BOYLES_LAW_Btn
        Me.BOYLES_LAW_Btn.FillColor = System.Drawing.Color.DarkGray
        Me.BOYLES_LAW_Btn.Font = New System.Drawing.Font("Lucida Sans Unicode", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BOYLES_LAW_Btn.ForeColor = System.Drawing.Color.White
        Me.BOYLES_LAW_Btn.HoverState.FillColor = System.Drawing.SystemColors.HotTrack
        Me.BOYLES_LAW_Btn.HoverState.Parent = Me.BOYLES_LAW_Btn
        Me.BOYLES_LAW_Btn.Location = New System.Drawing.Point(734, 17)
        Me.BOYLES_LAW_Btn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.BOYLES_LAW_Btn.Name = "BOYLES_LAW_Btn"
        Me.BOYLES_LAW_Btn.ShadowDecoration.Parent = Me.BOYLES_LAW_Btn
        Me.BOYLES_LAW_Btn.Size = New System.Drawing.Size(187, 46)
        Me.BOYLES_LAW_Btn.TabIndex = 17
        Me.BOYLES_LAW_Btn.Text = "BOYLES LAW"
        '
        'Guna2CirclePictureBox1
        '
        Me.Guna2CirclePictureBox1.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.Guna2CirclePictureBox1.Image = CType(resources.GetObject("Guna2CirclePictureBox1.Image"), System.Drawing.Image)
        Me.Guna2CirclePictureBox1.Location = New System.Drawing.Point(18, 14)
        Me.Guna2CirclePictureBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Guna2CirclePictureBox1.Name = "Guna2CirclePictureBox1"
        Me.Guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CirclePictureBox1.ShadowDecoration.Parent = Me.Guna2CirclePictureBox1
        Me.Guna2CirclePictureBox1.Size = New System.Drawing.Size(240, 214)
        Me.Guna2CirclePictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Guna2CirclePictureBox1.TabIndex = 13
        Me.Guna2CirclePictureBox1.TabStop = False
        '
        'Guna2HtmlLabel10
        '
        Me.Guna2HtmlLabel10.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel10.AutoSize = False
        Me.Guna2HtmlLabel10.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel10.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel10.ForeColor = System.Drawing.Color.OrangeRed
        Me.Guna2HtmlLabel10.Location = New System.Drawing.Point(1183, 45)
        Me.Guna2HtmlLabel10.Name = "Guna2HtmlLabel10"
        Me.Guna2HtmlLabel10.Size = New System.Drawing.Size(667, 39)
        Me.Guna2HtmlLabel10.TabIndex = 16
        Me.Guna2HtmlLabel10.Text = "......Creative & Innovative"
        Me.Guna2HtmlLabel10.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.Guna2HtmlLabel10.UseGdiPlusTextRendering = True
        '
        'Guna2HtmlLabel9
        '
        Me.Guna2HtmlLabel9.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Guna2HtmlLabel9.AutoSize = False
        Me.Guna2HtmlLabel9.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel9.Font = New System.Drawing.Font("Arial", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel9.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Guna2HtmlLabel9.Location = New System.Drawing.Point(422, 5)
        Me.Guna2HtmlLabel9.Name = "Guna2HtmlLabel9"
        Me.Guna2HtmlLabel9.Size = New System.Drawing.Size(1485, 45)
        Me.Guna2HtmlLabel9.TabIndex = 15
        Me.Guna2HtmlLabel9.Text = "WELCOME TO AfOOTECH GLOBAL MULTI-FUNCTION CALCULATOR"
        Me.Guna2HtmlLabel9.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        Me.Guna2HtmlLabel9.UseGdiPlusTextRendering = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1912, 1086)
        Me.Controls.Add(Me.Guna2Panel1)
        Me.Controls.Add(Me.Guna2CustomGradientPanel1)
        Me.Controls.Add(Me.simple_calc_panel)
        Me.Controls.Add(Me.home_page_panel)
        Me.Controls.Add(Me.Guna2Panel2)
        Me.Controls.Add(Me.Gp_Calcu_Panel2)
        Me.Controls.Add(Me.AgeCalc_Panel2)
        Me.Controls.Add(Me.Boyleslaw_panel)
        Me.Controls.Add(Me.loan_app_panel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.home_page_panel.ResumeLayout(False)
        Me.loan_app_panel.ResumeLayout(False)
        Me.loan_app_panel.PerformLayout()
        CType(Me.Guna2PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GroupBox8.ResumeLayout(False)
        Me.Guna2GroupBox8.PerformLayout()
        Me.Guna2GroupBox11.ResumeLayout(False)
        Me.Guna2GroupBox7.ResumeLayout(False)
        Me.Guna2GroupBox7.PerformLayout()
        Me.Boyleslaw_panel.ResumeLayout(False)
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GroupBox5.ResumeLayout(False)
        Me.Guna2GroupBox5.PerformLayout()
        Me.Guna2GroupBox6.ResumeLayout(False)
        Me.Guna2GroupBox6.PerformLayout()
        Me.Guna2GroupBox10.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.AgeCalc_Panel2.ResumeLayout(False)
        Me.AgeCalc_Panel2.PerformLayout()
        CType(Me.Guna2PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GroupBox4.ResumeLayout(False)
        Me.Gp_Calcu_Panel2.ResumeLayout(False)
        Me.Guna2GroupBox17.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.first_semester_Panel.ResumeLayout(False)
        Me.Guna2GroupBox13.ResumeLayout(False)
        Me.Guna2GroupBox13.PerformLayout()
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        Me.second_semester_Panel.ResumeLayout(False)
        Me.Guna2GroupBox16.ResumeLayout(False)
        Me.Guna2GroupBox16.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        Me.Guna2Panel2.ResumeLayout(False)
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2GroupBox2.ResumeLayout(False)
        Me.Guna2GroupBox2.PerformLayout()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.simple_calc_panel.ResumeLayout(False)
        Me.simple_calc_panel.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Guna2Panel1.ResumeLayout(False)
        Me.Guna2CustomGradientPanel1.ResumeLayout(False)
        Me.Guna2CustomGradientPanel2.ResumeLayout(False)
        CType(Me.Guna2CirclePictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents welc_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents creative_label As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents home_page_panel As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents loan_app_panel As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Boyleslaw_panel As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2PictureBox5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents AgeCalc_Panel2 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2PictureBox8 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Guna2PictureBox6 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents lstPaymentSchedule As System.Windows.Forms.ListBox
    Friend WithEvents Gp_Calcu_Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2Panel2 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents btnClear As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnUnitConverter As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents input_con As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents cmbUnit As Guna.UI2.WinForms.Guna2ComboBox
    Friend WithEvents Guna2PictureBox4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2GroupBox2 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents ClearButton As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents btnCalculateAge As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents txtBirthMonth As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents txtBirthDay As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents txtBirthYear As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel7 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel6 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents days_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents months_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents years_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox3 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox4 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel8 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Clear_txt As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents calc_boyles_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents result_txtt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox5 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox6 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents btnCalculateLoan As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2GroupBox7 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents txtLoanAmount As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtLoanTerm As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox8 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2HtmlLabel17 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents txtDisplay As System.Windows.Forms.Label
    Friend WithEvents btnBackspace As System.Windows.Forms.Button
    Friend WithEvents btnDel As System.Windows.Forms.Button
    Friend WithEvents btnNo7 As System.Windows.Forms.Button
    Friend WithEvents btnClr As System.Windows.Forms.Button
    Friend WithEvents btnNegate As System.Windows.Forms.Button
    Friend WithEvents btnNo4 As System.Windows.Forms.Button
    Friend WithEvents btnNo8 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents btnNo9 As System.Windows.Forms.Button
    Friend WithEvents btnNoplus As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents btnDot As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents btnEquals As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents txtShow As System.Windows.Forms.TextBox
    Friend WithEvents Guna2PictureBox3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents simple_calc_panel As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2GroupBox11 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox10 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox12 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Guna2GroupBox17 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents first_semester_calc_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents second_semester_calc_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents second_semester_Panel As System.Windows.Forms.Panel
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents DevOp207_txt As System.Windows.Forms.TextBox
    Friend WithEvents Guna2GroupBox16 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents GradeClassSecond_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents TotalGPSecond_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents calcSecond_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents ClearSecond_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents TotalGPASecond_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtTotalCourseUnits2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents AA206_txt As System.Windows.Forms.TextBox
    Friend WithEvents SQT205_txt As System.Windows.Forms.TextBox
    Friend WithEvents UIUX202_txt As System.Windows.Forms.TextBox
    Friend WithEvents AI204_txt As System.Windows.Forms.TextBox
    Friend WithEvents DBMS201_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label102 As System.Windows.Forms.Label
    Friend WithEvents Label105 As System.Windows.Forms.Label
    Friend WithEvents Label103 As System.Windows.Forms.Label
    Friend WithEvents Label104 As System.Windows.Forms.Label
    Friend WithEvents Label106 As System.Windows.Forms.Label
    Friend WithEvents Label107 As System.Windows.Forms.Label
    Friend WithEvents Label109 As System.Windows.Forms.Label
    Friend WithEvents Label108 As System.Windows.Forms.Label
    Friend WithEvents Clear As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents first_semester_Panel As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2TextBox10 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox11 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox12 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2TextBox13 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2GroupBox13 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents TotalGPFirst_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents GPAFirst_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents GradeClassFirst_txt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents txtCourseUnitsFirst As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents ClearFirst_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents calcFirst_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents v2_txt As System.Windows.Forms.TextBox
    Friend WithEvents v1_txt As System.Windows.Forms.TextBox
    Friend WithEvents p2_txt As System.Windows.Forms.TextBox
    Friend WithEvents p1_txt As System.Windows.Forms.TextBox
    Friend WithEvents close_button As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents mini_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2Panel1 As Guna.UI2.WinForms.Guna2Panel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2CustomGradientPanel1 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2HtmlLabel11 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2CirclePictureBox1 As Guna.UI2.WinForms.Guna2CirclePictureBox
    Friend WithEvents Guna2HtmlLabel10 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel9 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2CustomGradientPanel2 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents GpCalcu_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents simple_calc_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Unit_converterBtn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2Button4 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents AgeCalc_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents LoanApp_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents BOYLES_LAW_Btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents home_btn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents AGD106_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NS105_txt As System.Windows.Forms.TextBox
    Friend WithEvents WAD104_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MAD102_txt As System.Windows.Forms.TextBox
    Friend WithEvents SDA103_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SDT101_txt As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TotalInterest As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TotalPrincipalReturnnn As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TotalPrincipalReturnn As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TotalInterestt As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents TextBox2 As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents btnPercent As System.Windows.Forms.Button
    Friend WithEvents btnOct As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents btnHex As System.Windows.Forms.Button
    Friend WithEvents btnMod As System.Windows.Forms.Button
    Friend WithEvents btnTan As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents btnBin As System.Windows.Forms.Button
    Friend WithEvents btnCos As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents btnExp As System.Windows.Forms.Button
    Friend WithEvents btnTanh As System.Windows.Forms.Button
    Friend WithEvents btnSin As System.Windows.Forms.Button
    Friend WithEvents btnCosh As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents BtnSqrt As System.Windows.Forms.Button
    Friend WithEvents btnSignh As System.Windows.Forms.Button
    Friend WithEvents btnLog As System.Windows.Forms.Button
    Friend WithEvents btnPi As System.Windows.Forms.Button
    Friend WithEvents Guna2GroupBox1 As Guna.UI2.WinForms.Guna2GroupBox
    Friend WithEvents v2_radio As System.Windows.Forms.RadioButton
    Friend WithEvents p1_radio As System.Windows.Forms.RadioButton
    Friend WithEvents v1_radio As System.Windows.Forms.RadioButton
    Friend WithEvents p2_radio As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox

End Class
